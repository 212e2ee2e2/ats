export interface ApiResponse {
  success: boolean;
  message?: string;
  error?: string;
}

export interface LinkResponse extends ApiResponse {
  link: string;
  qrCode: string;
  random: string;
  sessionId: string;
  proxy_session: string;
}

export interface StatusData {
  status: 'NEW' | 'SCAN' | 'CONFIRM' | 'EXPIRED';
  token: string | null;
  code: string | null;
  bncLocation: string | null;
}

export interface StatusResponse extends ApiResponse {
  code: string;
  message: string | null;
  messageDetail: string | null;
  data: StatusData;
}