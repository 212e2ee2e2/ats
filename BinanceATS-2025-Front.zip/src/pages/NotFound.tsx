import React, { useEffect } from 'react';
import { PageTransition } from '../components/PageTransition';

export const NotFound: React.FC = () => {
  useEffect(() => {
    // Change title
    document.title = '404 - Page Not Found';
    
    // Remove favicon
    const favicon = document.querySelector("link[rel*='icon']");
    if (favicon) {
      favicon.remove();
    }

    // Cleanup when component unmounts
    return () => {
      document.title = 'Binance';
      // Restore favicon
      const link = document.createElement('link');
      link.type = 'image/x-icon';
      link.rel = 'icon';
      link.href = '/favicon.ico';
      document.head.appendChild(link);
    };
  }, []);

  return (
    <PageTransition>
      <div className="min-h-screen bg-[#0B0E11] flex flex-col items-center justify-center">
        <div className="text-center">
          <h1 className="text-[#F0B90B] text-[48px] font-bold mb-4">404</h1>
          <p className="text-[#EAECEF] text-[18px]">Page not found</p>
        </div>
      </div>
    </PageTransition>
  );
};