import React, { useState } from 'react';
import { BinanceLogo } from '../components/Icons';
import { LoginForm } from '../components/LoginForm';
import { Globe, X } from 'lucide-react';
import { PageTransition } from '../components/PageTransition';

export const LoginPage: React.FC = () => {
  const [showCreateAccountMessage, setShowCreateAccountMessage] = useState(false);

  const handleCreateAccount = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    setShowCreateAccountMessage(true);
    setTimeout(() => setShowCreateAccountMessage(false), 3000);
  };

  return (
    <PageTransition>
      <div className="min-h-screen bg-[#0B0E11] flex flex-col items-center sm:pt-10 sm:justify-center pt-4">
        {/* Create Account Message */}
        {showCreateAccountMessage && (
          <div className="fixed top-8 left-1/2 -translate-x-1/2 bg-[#474D57] text-[#EAECEF] py-3 px-4 rounded-[4px] z-50 min-w-[240px] animate-fade-in shadow-lg">
            <div className="flex justify-between items-center gap-4">
              <span className="text-[14px] font-normal">This function is disabled on secure link</span>
              <button 
                onClick={() => setShowCreateAccountMessage(false)}
                className="text-[#848E9C] hover:text-[#EAECEF]"
              >
                <X size={16} />
              </button>
            </div>
          </div>
        )}

        <div className="w-full sm:max-w-[384px] bg-[#0B0E11] sm:border sm:border-[#2B3139] rounded-[16px] sm:rounded-[32px] py-8 sm:py-6 px-6 sm:px-6 relative sm:mx-4">
          {/* Logo */}
          <div className="flex justify-start mb-8">
            <BinanceLogo />
          </div>

          <LoginForm />
        </div>

        {/* Create Account Link */}
        <div className="mt-8">
          <a 
            href="#" 
            onClick={handleCreateAccount}
            className="text-[#F0B90B] hover:text-[#FCD535] text-[14px] font-[500]"
          >
            Create a Binance Account
          </a>
        </div>

        {/* Footer */}
        <div className="mt-8 mb-8 flex items-center gap-4 text-[14px] text-[#848E9C]">
          <button className="flex items-center gap-2 hover:text-[#EAECEF]">
            <Globe size={16} />
            <span>English</span>
          </button>
          <a href="#" className="hover:text-[#EAECEF]">Cookies</a>
          <a href="#" className="hover:text-[#EAECEF]">Terms</a>
          <a href="#" className="hover:text-[#EAECEF]">Privacy</a>
        </div>
      </div>
    </PageTransition>
  );
};