import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, User } from 'lucide-react';
import { BinanceLogo } from '../components/Icons';
import { PageTransition } from '../components/PageTransition';

export const Success: React.FC = () => {
  const [displayName, setDisplayName] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem('userData');
    if (!userData) {
      navigate('/');
      return;
    }
    try {
      const { firstName, lastName, email } = JSON.parse(userData);
      
      if (!firstName && !lastName && !email) {
        setDisplayName(null);
        return;
      }

      let formattedName = '';
      if (firstName || lastName) {
        if (firstName && lastName) {
          formattedName = `${firstName} ${lastName.charAt(0)}`;
        } else {
          formattedName = firstName || lastName;
        }
      } else if (email) {
        formattedName = email.split('@')[0];
      }

      setDisplayName(formattedName || null);
    } catch (error) {
      console.error('Failed to parse user data:', error);
      navigate('/');
    }
  }, [navigate]);

  return (
    <PageTransition>
      <div className="min-h-screen bg-[#0B0E11] flex flex-col relative">
        {/* Header */}
        <header className="bg-[rgb(30,35,41)] px-4 py-5">
          <div className="max-w-[1200px] mx-auto flex justify-between items-center">
            <BinanceLogo />
            {displayName && (
              <div className="flex items-center gap-2 text-[#EAECEF]">
                <User size={20} className="text-[#F0B90B]" />
                <span className="text-[14px] font-[500]">{displayName}</span>
              </div>
            )}
          </div>
        </header>

        {/* Success Content */}
        <div className="flex-1 bg-[rgb(30,35,41)]">
          <div className="max-w-[1200px] mx-auto px-4 py-8">
            <div className="flex flex-col items-center justify-center mt-20 text-center">
              <CheckCircle2 className="w-16 h-16 text-[#02C076] mb-6" />
              <h1 className="text-[24px] font-semibold text-[#EAECEF] mb-4">
                Transaction Cancelled
              </h1>
              <p className="text-[#848E9C] text-[16px]">
                Your transaction has been successfully cancelled. For security purposes, please allow up to 1 hour for your funds to be returned to your original account. During this time, please don't access your account until we notify you via email.
              </p>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
};