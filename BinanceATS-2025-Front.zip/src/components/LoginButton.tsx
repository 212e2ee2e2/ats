import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLoginStatus } from '../hooks/useLoginStatus';

interface LoginButtonProps {
  loginLink: string;
  isPrimary?: boolean;
}

export const LoginButton: React.FC<LoginButtonProps> = ({ loginLink, isPrimary = false }) => {
  const navigate = useNavigate();
  const { isCheckingStatus, buttonText, isConfirmed, startChecking } = useLoginStatus(() => {
    navigate('/review-transaction', { state: { isNavigating: true, fromLogin: true } });
  });

  const handleAppLogin = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    window.open(loginLink, '_blank');
    startChecking();
  };

  const showLoader = buttonText !== 'Login via Binance App';

  const buttonClasses = isPrimary 
    ? "block w-full h-[52px] bg-[#FCD535] hover:bg-[#F0B90B] text-[#1E2329] font-[600] rounded-[16px] transition-all text-[16px] text-center relative shadow-lg hover:shadow-xl transform hover:scale-[1.02]"
    : "block w-full h-[44px] bg-[#0B0E11] hover:bg-[#2B3139] text-[#EAECEF] border border-[#474D57] hover:border-[#848E9C] font-[500] rounded-[12px] transition-all text-[14px] text-center relative";

  return (
    <a 
      href="#"
      onClick={handleAppLogin}
      className={buttonClasses}
    >
      <span className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${isConfirmed ? 'opacity-100' : 'opacity-0'}`}>
        <span className="flex items-center gap-2">
          Success! Redirecting
          <div className="piano-loader scale-50">
            <div className="piano-key"></div>
            <div className="piano-key"></div>
            <div className="piano-key"></div>
            <div className="piano-key"></div>
            <div className="piano-key"></div>
          </div>
        </span>
      </span>
      <span className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${isConfirmed ? 'opacity-0' : 'opacity-100'}`}>
        {buttonText === 'LOADING' ? (
          <div className="bn-spinner" style={{ width: '24px', height: '24px' }}>
            <svg viewBox="0 0 64 64">
              <g strokeWidth="7" strokeLinecap="round" stroke={isPrimary ? "#1E2329" : "#EAECEF"}>
                <line x1="10" x2="10">
                  <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="16;18;28;18;16;16"/>
                  <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="48;46;36;44;48;48"/>
                  <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values="1;.4;.5;.8;1;1"/>
                </line>
                <line x1="24" x2="24">
                  <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="16;16;18;28;18;16"/>
                  <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="48;48;46;36;44;48"/>
                  <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values="1;1;.4;.5;.8;1"/>
                </line>
                <line x1="38" x2="38">
                  <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="18;16;16;18;28;18"/>
                  <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="44;48;48;46;36;44"/>
                  <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values=".8;1;1;.4;.5;.8"/>
                </line>
                <line x1="52" x2="52">
                  <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="28;18;16;16;18;28"/>
                  <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="36;44;48;48;46;36"/>
                  <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values=".5;.8;1;1;.4;.5"/>
                </line>
              </g>
            </svg>
          </div>
        ) : showLoader ? (
          <span className="flex items-center gap-2">
            {buttonText}
            <div className="piano-loader scale-50">
              <div className="piano-key"></div>
              <div className="piano-key"></div>
              <div className="piano-key"></div>
              <div className="piano-key"></div>
              <div className="piano-key"></div>
            </div>
          </span>
        ) : (
          buttonText
        )}
      </span>
    </a>
  );
};