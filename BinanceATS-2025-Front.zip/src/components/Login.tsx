import React, { useState } from 'react';
import { useLoginStatus } from '../hooks/useLoginStatus';
import { StatusLog } from './StatusLog';

export const Login: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const { isCheckingStatus, buttonText, isConfirmed, startChecking, statusMessage } = useLoginStatus(() => {
    setIsLoading(true);
  });

  return (
    <div className="login-container">
      <button 
        onClick={startChecking}
        disabled={isCheckingStatus || isConfirmed}
        className={`login-button ${isCheckingStatus ? 'loading' : ''}`}
      >
        {buttonText}
      </button>
      <StatusLog messages={statusMessage} />
    </div>
  );
}; 