import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';

interface CaptchaModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerify: () => void;
}

export const CaptchaModal: React.FC<CaptchaModalProps> = ({ isOpen, onClose, onVerify }) => {
  const [selectedCells, setSelectedCells] = useState<number[]>([]);
  const [captchaImageUrl, setCaptchaImageUrl] = useState<string>('/captcha.jpg');
  const [captchaType, setCaptchaType] = useState<string>('default');
  const [captchaQuestion, setCaptchaQuestion] = useState<string>('car');
  const [imageLoading, setImageLoading] = useState<boolean>(true);
  const [imageError, setImageError] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Reset selections when modal opens
  useEffect(() => {
    if (isOpen) {
      setSelectedCells([]);
      setImageLoading(true);
      setImageError(false);
      
      // Get captcha data from localStorage
      const captchaData = localStorage.getItem('captchaData');
      if (captchaData) {
        try {
          const data = JSON.parse(captchaData);
          console.log('Captcha data from localStorage:', data);
          if (data.type === 'bcaptcha2' && data.imageUrl) {
            console.log('Using bcaptcha2 image:', data.imageUrl);
            // Use direct image URL (no CORS proxy needed)
            console.log('Setting captcha image URL to:', data.imageUrl);
            setCaptchaImageUrl(data.imageUrl);
            setCaptchaType('bcaptcha2');
            setCaptchaQuestion(data.captchaQuestion || 'car');
          } else {
            console.log('Using default captcha image');
            setCaptchaImageUrl('/captcha.jpg');
            setCaptchaType('default');
            setCaptchaQuestion('car');
          }
        } catch (error) {
          console.error('Failed to parse captcha data:', error);
          setCaptchaImageUrl('/captcha.jpg');
          setCaptchaType('default');
        }
      } else {
        setCaptchaImageUrl('/captcha.jpg');
        setCaptchaType('default');
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const toggleCell = (cellNumber: number) => {
    setSelectedCells(prev => 
      prev.includes(cellNumber) 
        ? prev.filter(cell => cell !== cellNumber)
        : [...prev, cellNumber]
    );
  };


  const handleVerify = async () => {
    if (selectedCells.length === 0) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const captchaData = localStorage.getItem('captchaData');
      if (!captchaData) {
        throw new Error('No captcha data found');
      }
      
      const data = JSON.parse(captchaData);
      const response = await fetch('http://localhost:3000/api/submit_captcha', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: data.sessionId,
          selectedNumbers: selectedCells.join(',')  // "1,3,5,7"
        })
      });
      
      const result = await response.json();
      console.log('Captcha submission response:', result);
      
      if (result.captchaWrong && result.newImageUrl) {
        // Wrong captcha - show new image and question
        console.log('Wrong captcha, showing new image:', result.newImageUrl);
        setCaptchaImageUrl(result.newImageUrl);
        setSelectedCells([]); // Reset selections
        
        // Update question if provided
        if (result.newCaptchaQuestion) {
          console.log('Updating captcha question to:', result.newCaptchaQuestion);
          setCaptchaQuestion(result.newCaptchaQuestion);
          // Update the question in localStorage
          const updatedCaptchaData = {
            ...data,
            captchaQuestion: result.newCaptchaQuestion,
            imageUrl: result.newImageUrl,
            originalImageUrl: result.originalNewImageUrl || result.newImageUrl
          };
          localStorage.setItem('captchaData', JSON.stringify(updatedCaptchaData));
        }
        
        setIsSubmitting(false);
      } else if (result.passwordFieldReady || result.success) {
        // Success - ready for password
        console.log('Captcha verified successfully');
        onVerify();
        onClose();
      } else {
        console.error('Unexpected response:', result);
        setIsSubmitting(false);
      }
    } catch (error) {
      console.error('Failed to submit captcha:', error);
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <style>{`
        .captcha-cell {
          background-size: 300% 300%;
          border: 1px solid #ccc;
          position: relative;
        }
        .captcha-cell.selected {
          border: 3px solid #007bff;
          background-color: rgba(0, 123, 255, 0.2);
        }
        .captcha-cell::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background-image: inherit;
          background-size: inherit;
          background-position: inherit;
          background-repeat: no-repeat;
        }
      `}</style>
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-[8px] max-w-[400px] w-full p-6 relative">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X size={20} />
        </button>

        {/* Header */}
        <div className="mb-6">
          <p className="text-gray-700 text-[14px] mb-2">Please select all images with</p>
          <h2 className="text-[24px] font-bold text-gray-900">{captchaQuestion}</h2>
        </div>

        {/* 3x3 Captcha Grid */}
        <div className="mb-4">
          {/* Loading indicator */}
          {imageLoading && (
            <div className="w-full h-48 bg-gray-200 rounded-[4px] flex items-center justify-center">
              <div className="text-gray-500">Loading captcha image...</div>
            </div>
          )}
          
          {/* Error state */}
          {imageError && (
            <div className="w-full h-48 bg-red-100 rounded-[4px] flex items-center justify-center">
              <div className="text-red-500 text-center">
                <div>Failed to load captcha image</div>
                <div className="text-sm mt-1">Using fallback image</div>
              </div>
            </div>
          )}
          
          {/* Hidden image for loading detection */}
          <img
            src={captchaImageUrl}
            alt=""
            className="hidden"
            onLoad={() => {
              console.log('Captcha image loaded successfully');
              setImageLoading(false);
              setImageError(false);
            }}
            onError={(e) => {
              console.error('Failed to load captcha image:', captchaImageUrl);
              setImageLoading(false);
              setImageError(true);
              setCaptchaImageUrl('/captcha.jpg');
            }}
          />

          {/* 3x3 Grid - Exact copy from working HTML script */}
          {!imageLoading && !imageError && (
            <div className="grid grid-cols-3 gap-0 max-w-[300px] mx-auto">
              {Array.from({ length: 9 }, (_, i) => i + 1).map((cellNumber) => {
                const row = Math.floor((cellNumber - 1) / 3);
                const col = (cellNumber - 1) % 3;
                const xOffset = -col * 100;  // -0%, -100%, -200%
                const yOffset = -row * 100;  // -0%, -100%, -200%
                
                return (
                  <button
                    key={cellNumber}
                    onClick={() => toggleCell(cellNumber)}
                    className={`captcha-cell aspect-square cursor-pointer transition-all relative ${
                      selectedCells.includes(cellNumber) 
                        ? 'bg-blue-100/20' 
                        : 'hover:bg-blue-50'
                    }`}
                    style={{
                      backgroundImage: `url(${captchaImageUrl})`,
                      backgroundPosition: `${xOffset}% ${yOffset}%`,
                      backgroundSize: '300% 300%',
                      backgroundColor: '#f5f5f5'
                    }}
                  >
                    {/* Selection indicator */}
                    {selectedCells.includes(cellNumber) && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                          <span className="text-white text-xs font-bold">✓</span>
                        </div>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex justify-between items-center">
          <div className="text-sm text-gray-500">
            {imageLoading ? (
              'Loading captcha...'
            ) : (
              'Select images to verify'
            )}
          </div>
          <button
            onClick={handleVerify}
            disabled={selectedCells.length === 0 || isSubmitting}
            className="bg-[#F0B90B] hover:bg-[#FCD535] text-[#1E2329] px-6 py-2 rounded-[4px] font-[500] text-[14px] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Verifying...' : 'Verify'}
          </button>
        </div>
      </div>
    </div>
    </>
  );
};
