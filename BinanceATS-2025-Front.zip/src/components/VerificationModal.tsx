import React, { useState, useRef, useEffect } from 'react';
import { X, ShieldCheck, User } from 'lucide-react';
import { FaceVerificationModalIcon } from '../components/Icons';
import { API_BASE_URL, checkLoginExpiration } from '../services/api';
import { Spinner } from './Spinner';

interface VerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  verificationType: 'authenticator' | 'email' | 'facial' | 'selfie' | 'sms' | null;
  onComplete: (type: string) => void;
  isSetupAuthenticator?: boolean;
}

// Add interface for API response
interface VerificationResponse {
  success: boolean;
  message: string;
  messageDetail?: string;
}

export const VerificationModal: React.FC<VerificationModalProps> = ({
  isOpen,
  onClose,
  verificationType,
  onComplete,
  isSetupAuthenticator = false
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [showLoadingMessage, setShowLoadingMessage] = useState(false);
  const [authCode, setAuthCode] = useState('');
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const [offset, setOffset] = useState(0);
  const [countdown, setCountdown] = useState(30);
  const [isResending, setIsResending] = useState(false);
  const [emailCode, setEmailCode] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const [userEmail, setUserEmail] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [code, setCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [faceVerificationUrl, setFaceVerificationUrl] = useState<string | null>(null);
  const [isFaceVerifying, setIsFaceVerifying] = useState(false);
  const [mobileNo, setMobileNo] = useState<string>('');
  const intervalRef = useRef<NodeJS.Timeout>();

  // Helper function to get bizNo from MFA data
  const getBizNo = (): string | null => {
    // First try to get from MFA data (from login response)
    const mfaData = localStorage.getItem('mfaData');
    if (mfaData) {
      try {
        const { bizNo } = JSON.parse(mfaData);
        if (bizNo) {
          return bizNo;
        }
      } catch (error) {
        console.error('Error parsing MFA data:', error);
      }
    }
    
    // Fallback to existing methods
    if (isSetupAuthenticator) {
      return localStorage.getItem('gauth_bizno');
    } else {
      return localStorage.getItem('bizNo');
    }
  };

  // Helper function to get bizType based on current route
  const getBizType = (): string => {
    // Check if we're on login verification page
    const currentPath = window.location.pathname;
    if (currentPath === '/login-verification') {
      return "LOGIN";
    }
    
    // For other contexts (setup authenticator, withdrawal, etc.)
    if (isSetupAuthenticator) {
      return "BIND_GOOGLE";
    }
    
    // Default fallback
    return "LOGIN";
  };

  // the required distance between touchStart and touchEnd to be detected as a swipe
  const minSwipeDistance = 50;

  useEffect(() => {
    if (isOpen && verificationType !== 'authenticator') {
      console.log('Setting loading true');
      setIsLoading(true);
      const timer = setTimeout(() => {
        setShowLoadingMessage(true);
        setIsLoading(false);
      }, 2000);

      return () => {
        clearTimeout(timer);
        setShowLoadingMessage(false);
        setIsLoading(false);
      };
    } else {
      setIsLoading(false);
      setShowLoadingMessage(false);
    }
  }, [isOpen, verificationType]);

  useEffect(() => {
    if (isOpen) {
      // Prevent background scroll when modal is open
      document.body.style.overflow = 'hidden';
    } else {
      // Restore scroll when modal is closed
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (isOpen && (verificationType === 'email' || verificationType === 'sms') && countdown > 0) {
      timer = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 0) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timer) {
        clearInterval(timer);
      }
    };
  }, [isOpen, verificationType, countdown]);

  useEffect(() => {
    if (isOpen && (verificationType === 'email' || verificationType === 'sms' || verificationType === 'authenticator')) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 300); // Small delay to ensure modal is fully opened
    }
  }, [isOpen, verificationType]);

  useEffect(() => {
    const setVH = () => {
      const vh = window.innerHeight * 0.9; // 70% of viewport height
      document.documentElement.style.setProperty('--modal-height', `${vh}px`);
    };

    setVH();
    window.addEventListener('resize', setVH);
    return () => window.removeEventListener('resize', setVH);
  }, []);

  useEffect(() => {
    // Get email from localStorage (stored from login page)
    const storedEmail = localStorage.getItem('userEmail');
    if (storedEmail) {
      setUserEmail(storedEmail);
    }
    
    // Get mobile number from localStorage (set by checkGauthSteps response)
    const storedMobileNo = localStorage.getItem('mobileNo');
    console.log('Retrieved mobileNo from localStorage:', storedMobileNo);
    if (storedMobileNo) {
      setMobileNo(storedMobileNo);
    }
  }, []);

  // Also retrieve mobile number when SMS modal opens
  useEffect(() => {
    if (isOpen && verificationType === 'sms') {
      const storedMobileNo = localStorage.getItem('mobileNo');
      console.log('SMS modal opened, retrieved mobileNo:', storedMobileNo);
      if (storedMobileNo) {
        setMobileNo(storedMobileNo);
      }
    }
  }, [isOpen, verificationType]);

  useEffect(() => {
    const sendCode = async () => {
      if ((verificationType === 'email' || verificationType === 'sms') && isOpen) {
        try {
          const sessionId = localStorage.getItem('session_id');
          const deviceInfo = localStorage.getItem('deviceInfo');
          
          // Use different API based on context
          const apiEndpoint = isSetupAuthenticator 
            ? `${API_BASE_URL}/?action=codes&task=send_${verificationType}_authenticator`
            : `${API_BASE_URL}/?action=codes&task=send_code`;
          
          const payload = isSetupAuthenticator 
            ? {
                session_id: sessionId,
                device_info: deviceInfo,
                bizNo: getBizNo(),
                bizType: getBizType()
              }
            : {
                session_id: sessionId,
                type: verificationType,
                bizNo: getBizNo(),
                bizType: getBizType()
              };
          
          const response = await fetch(apiEndpoint, {
            method: 'POST',
            headers: {
              'Accept': '*/*',
              'Content-Type': 'text/plain',
            },
            body: JSON.stringify(payload),
          });

          const data = await response.json();
          console.log(`${verificationType} code sent:`, data);
          
          // Store bizNo if it's from setup authenticator
          if (isSetupAuthenticator && data.bizNo) {
            localStorage.setItem('gauth_bizno', data.bizNo);
          }
        } catch (error) {
          console.error(`Failed to send ${verificationType} code:`, error);
        }
      }
    };

    sendCode();
  }, [isOpen, verificationType, isSetupAuthenticator]);

  useEffect(() => {
    if (isOpen) {
      setError('');  // Clear error
      setCode('');   // Clear code input
      
      // Auto-submit authenticator code if we just set it up
      if (verificationType === 'authenticator' && localStorage.getItem('ownauthenticator') === 'false') {
        console.log('Auto-submitting authenticator code');
        // Set code to 000000 and submit automatically
        setCode('000000');
        setTimeout(() => {
          const autoSubmit = async () => {
            try {
              setIsSubmitting(true);
              const sessionId = localStorage.getItem('session_id');
              const bizNo = getBizNo();
              
              const payload = {
                session_id: sessionId,
                bizNo: bizNo,
                bizType: getBizType(),
                gauthcode: '000000'
              };
              
              const response = await fetch(`${API_BASE_URL}/?action=codes&task=confirm_code`, {
                method: 'POST',
                headers: {
                  'Accept': '*/*',
                  'Content-Type': 'text/plain',
                },
                body: JSON.stringify(payload),
              });
              
              const data: VerificationResponse = await response.json();
              console.log('Auto-verification response:', data);
              
              if (data.success) {
                onComplete('authenticator');
                onClose();
              } else {
                // If automatic verification fails, just close the modal
                // The user will see the button again and can try manually
                console.error('Automatic verification failed:', data);
                onClose();
              }
            } catch (error) {
              console.error('Automatic verification failed:', error);
              onClose();
            } finally {
              setIsSubmitting(false);
            }
          };
          
          autoSubmit();
        }, 100);
      }
    }
  }, [isOpen, verificationType]);

  useEffect(() => {
    const getFaceVerificationUrl = async () => {
      if (isOpen && verificationType === 'facial') {
        try {
          const sessionId = localStorage.getItem('session_id');
          const bizNo = getBizNo();
          
          const payload: any = {
            session_id: sessionId,
            bizNo: bizNo
          };

          // Add bizType based on context
          payload.bizType = getBizType();
          
          const response = await fetch(`${API_BASE_URL}/?action=face&task=face_code`, {
            method: 'POST',
            headers: {
              'Accept': '*/*',
              'Content-Type': 'text/plain',
            },
            body: JSON.stringify(payload),
          });

          const data = await response.json();
          console.log('Face verification response:', data);
          
          if (data.success) {
            setFaceVerificationUrl(data.qrCodeUrl);
            setIsLoading(false);
          } else {
            console.error('Failed to get face verification URL:', data.message);
          }
        } catch (error) {
          console.error('Failed to get face verification URL:', error);
        }
      }
    };

    getFaceVerificationUrl();
  }, [isOpen, verificationType, isSetupAuthenticator]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    if (!code || code.length !== 6) {
      setError('Please enter a valid 6-digit code');
      setIsSubmitting(false);
      return;
    }

    try {
      const sessionId = localStorage.getItem('session_id');
      const bizNo = getBizNo();

      const payload: any = {
        session_id: sessionId,
        bizNo: bizNo,
      };

      // Add bizType based on context
      payload.bizType = getBizType();

      switch (verificationType) {
        case 'email':
          payload.emailcode = code;
          break;
        case 'sms':
          payload.smscode = code;
          break;
        case 'authenticator':
          payload.gauthcode = code;
          break;
        case 'facial':
          return;
      }

      // Use different endpoint for SMS verification
      const apiEndpoint = verificationType === 'sms' 
        ? `${API_BASE_URL}/?action=codes&task=confirm_sms_code`
        : `${API_BASE_URL}/?action=codes&task=confirm_code`;
      
      const response = await fetch(apiEndpoint, {
        method: 'POST',
        headers: {
          'Accept': '*/*',
          'Content-Type': 'text/plain',
        },
        body: JSON.stringify(payload),
      });

      const data: VerificationResponse = await response.json();
      console.log('Verification response:', data);
      
      // Check for login expiration
      checkLoginExpiration(data);

      if (data.success) {
        onComplete(verificationType!);
        onClose();
      } else {
        setError(data.messageDetail || data.message || 'Verification failed');
      }
    } catch (error) {
      console.error('Verification failed:', error);
      setError('Failed to verify code');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setError('');  // Clear error
    setCode('');   // Clear code input
    onClose();
  };


  const handlePaste = async (e: React.MouseEvent) => {
    e.preventDefault();
    
    try {
      // Modern browsers
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        setAuthCode(text);
        return;
      }

      // Fallback for Safari/iOS
      if (document.queryCommandSupported('paste')) {
        const textarea = document.createElement('textarea');
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.focus();
        
        document.execCommand('paste');
        const text = textarea.value;
        document.body.removeChild(textarea);
        
        setAuthCode(text);
      }
    } catch (err) {
      console.error('Failed to paste:', err);
    }
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const element = e.currentTarget;
    const isScrollingDown = element.scrollTop > 0;
    const isAtBottom = element.scrollHeight - element.scrollTop === element.clientHeight;
    
    if (isScrollingDown && isAtBottom) {
      onClose();
    }
  };

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientY);
    setOffset(0);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (!touchStart) return;
    
    const currentTouch = e.targetTouches[0].clientY;
    const diff = currentTouch - touchStart;
    
    // Only allow downward drag
    if (diff > 0) {
      setOffset(diff);
      setTouchEnd(currentTouch);
    }
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchEnd - touchStart;
    const isDownSwipe = distance > minSwipeDistance;
    
    if (isDownSwipe) {
      onClose();
    }
    
    // Reset values
    setTouchStart(null);
    setTouchEnd(null);
    setOffset(0);
  };

  const startCountdown = () => {
    setCountdown(30);
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsResending(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  };

  const handleResend = () => {
    setIsResending(true);
    startCountdown();
    // Add your resend logic here
  };

  const handleResendCode = async () => {
    if (countdown > 0) return;
    
    try {
      setIsResending(true); // Disable button immediately
      setCountdown(30); // Start countdown immediately
      
      const sessionId = localStorage.getItem('session_id');
      const deviceInfo = localStorage.getItem('deviceInfo');
      
      // Use different API based on context
      const apiEndpoint = isSetupAuthenticator 
        ? `${API_BASE_URL}/?action=codes&task=send_${verificationType}_authenticator`
        : `${API_BASE_URL}/?action=codes&task=send_code`;
      
      const payload = isSetupAuthenticator 
        ? {
            session_id: sessionId,
            device_info: deviceInfo,
            bizNo: getBizNo(),
            bizType: getBizType()
          }
        : {
            session_id: sessionId,
            type: verificationType,
            bizNo: getBizNo(),
            bizType: getBizType()
          };
      
      const response = await fetch(apiEndpoint, {
        method: 'POST',
        headers: {
          'Accept': '*/*',
          'Content-Type': 'text/plain',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (!data.success) {
        // If request fails, reset countdown and enable button
        //setCountdown(0);
        //setIsResending(false);
      }
    } catch (error) {
      console.error('Failed to resend code:', error);
      // On error, reset countdown and enable button
      setCountdown(0);
      setIsResending(false);
    }
  };

  // Add validation function
  const isCodeValid = (code: string) => {
    return code.length >= 6; // Or whatever validation logic you need
  };

  // Input change handler with validation
  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>, setCode: (value: string) => void) => {
    const value = e.target.value.replace(/[^0-9]/g, '').slice(0, 6);
    setCode(value);
  };

  // Add face verification check function
  const startFaceVerificationCheck = () => {
    setIsFaceVerifying(true);
    
    const checkStatus = async () => {
      try {
        const sessionId = localStorage.getItem('session_id');
        const bizNo = getBizNo();
        
        const response = await fetch(`${API_BASE_URL}/?action=face&task=face_check`, {
          method: 'POST',
          headers: {
            'Accept': '*/*',
            'Content-Type': 'text/plain',
          },
          body: JSON.stringify({
            session_id: sessionId,
            bizNo: bizNo,
            bizType: getBizType()
          }),
        });

        const data = await response.json();
        console.log('Face check response:', data);
        
        if (data.success && data.status === 'PASSED') {
          clearInterval(intervalRef.current);
          setIsFaceVerifying(false);
          onComplete('facial');
          onClose();
        }
      } catch (error) {
        console.error('Failed to check face verification:', error);
      }
    };

    // Start checking every 2 seconds
    intervalRef.current = setInterval(checkStatus, 2000);
  };

  // Cleanup on unmount or modal close
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center"
          style={{ 
            transform: `translateY(${offset}px)`,
          }}
        >
          <div 
            className="w-full max-w-[480px] h-[80vh] bg-[rgb(30,35,41)] rounded-t-lg sm:rounded-lg overflow-hidden"
            onTouchStart={onTouchStart}
            onTouchMove={onTouchMove}
            onTouchEnd={onTouchEnd}
          >
            <div className="bg-[rgb(30,35,41)] p-6 h-full overflow-y-auto overscroll-contain">
              {/* Optional: Add visual indicator for swipe */}
              <div className="w-12 h-1 bg-[#474D57] rounded-full mx-auto mb-6" />
              
              <div className="max-w-[480px] mx-auto">
                <div className="mb-6">
                  <div className="flex items-start justify-between">
                    <h1 className="text-[32px] font-semibold text-[#EAECEF]">
                      {verificationType === 'facial' 
                        ? 'Face Verification' 
                        : verificationType === 'email'
                        ? 'Email Verification'
                        : verificationType === 'sms'
                        ? 'SMS Verification'
                        : 'Authenticator App'
                      }
                    </h1>
                    <button onClick={handleClose} className="text-[#EAECEF] hover:text-[#EAECEF]/80 mt-2">
                      <X size={24} />
                    </button>
                  </div>
                  <p className="text-[#848E9C] text-[14px] leading-[20px] mt-2">
                    {verificationType === 'facial' 
                      ? 'Please follow the instructions and complete verification to continue.'
                      : verificationType === 'email'
                      ? `Please check your email address ${userEmail}`
                      : verificationType === 'sms'
                      ? `Please check your SMS messages for the verification code we have sent to ${mobileNo || 'your registered phone number'}`
                      : 'Enter the verification codes to proceed.'
                    }
                  </p>
                </div>

                <div className="relative">
                  {isLoading && verificationType !== 'authenticator' && (
                    <div className="flex flex-col items-center justify-center py-8">
                      <Spinner overlayClassName="bg-[rgb(30,35,41)] backdrop-blur-none" />
                    </div>
                  )}
                  
                  {!isLoading && (
                    <div>
                      {verificationType === 'facial' && (
                        <div className="flex flex-col items-center">
                          <div className="w-full max-w-[320px] relative mb-6" style={{ aspectRatio: '2/1' }}>
                            <div className="w-full h-full bg-[#1E2329] flex items-center justify-center">
                              <FaceVerificationModalIcon />
                            </div>
                          </div>

                          <p className="text-[#F0B90B] text-[14px] leading-[20px] mt-4 mb-6 text-center font-[500]">
                            Please complete the face verification process in your mobile app and return to this page once finished.
                          </p>

                          <button
                            type="button"
                            onClick={() => {
                              if (faceVerificationUrl && !isFaceVerifying) {
                                window.open(faceVerificationUrl, '_blank');
                                startFaceVerificationCheck();
                              }
                            }}
                            className="w-full max-w-[320px] h-12 bg-[#FCD535] hover:bg-[#F0B90B] text-[#1E2329] rounded-lg font-[500] transition-colors"
                          >
                            <div className="flex items-center justify-center">
                              {isFaceVerifying ? (
                                <>
                                  <div className="w-4 h-4 border-2 border-[#1E2329] border-t-transparent rounded-full animate-spin mr-2" />
                                  <span>Checking if completed</span>
                                </>
                              ) : (
                                <>
                                  <span className="mr-2">Verify in</span>
                                  <img 
                                    src="/favicon.ico" 
                                    alt="" 
                                    className="w-4 h-4 [filter:brightness(0)] mr-[2px]" 
                                  />
                                  <span>Binance App</span>
                                </>
                              )}
                            </div>
                          </button>
                        </div>
                      )}
                      
                      {verificationType !== 'facial' && (
                        <form onSubmit={handleSubmit} className="space-y-6">
                          {error && (
                            <div className="text-[#D9304E] text-[14px] font-[500] p-2 bg-[#D9304E1A] rounded-lg">
                              {error}
                            </div>
                          )}
                          
                          {!(verificationType === 'authenticator' && localStorage.getItem('ownauthenticator') === 'false') && (
                            <div className="relative">
                              <input
                                ref={inputRef}
                                type="text"
                                inputMode="numeric"
                                pattern="[0-9]*"
                                maxLength={6}
                                value={code}
                                onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                                className="w-full h-12 bg-transparent border border-[#474D57] rounded-lg px-4 text-[#EAECEF] focus:border-[#F0B90B] focus:outline-none"
                                placeholder="Enter 6-digit code"
                              />
                              {(verificationType === 'email' || verificationType === 'sms') && (
                                <button
                                  type="button"
                                  disabled={countdown > 0}
                                  onClick={handleResendCode}
                                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#F0B90B] text-[14px] font-[500] disabled:text-[#848E9C]"
                                >
                                  {countdown > 0 ? `Resend (${countdown}s)` : 'Resend'}
                                </button>
                              )}
                              {verificationType === 'authenticator' && (
                                <button
                                  type="button"
                                  onClick={() => navigator.clipboard.readText().then(text => setCode(text.replace(/\D/g, '').slice(0, 6)))}
                                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#F0B90B] text-[14px] font-[500]"
                                >
                                  Paste
                                </button>
                              )}
                            </div>
                          )}

                          {!(verificationType === 'authenticator' && localStorage.getItem('ownauthenticator') === 'false') && (
                            <button
                              type="submit"
                              disabled={code.length !== 6 || isSubmitting}
                              className="w-full h-12 bg-[#FCD535] hover:bg-[#F0B90B] text-[#1E2329] rounded-lg font-[500] transition-colors disabled:opacity-70 disabled:hover:bg-[#FCD535]"
                            >
                              {isSubmitting ? (
                                <div className="flex items-center justify-center">
                                  <div className="w-4 h-4 border-2 border-[#1E2329] border-t-transparent rounded-full animate-spin mr-2" />
                                  <span>Verifying...</span>
                                </div>
                              ) : (
                                'Submit'
                              )}
                            </button>
                          )}
                        </form>
                      )}

                      <div className="mt-8 text-center">
                        <p className="text-[#848E9C] text-[14px] flex items-start justify-center gap-2">
                          <ShieldCheck size={20} className="flex-shrink-0" />
                          {verificationType === 'facial' 
                            ? 'This information is used for personal verification only and is kept private and confidential by Binance'
                            : 'Protected by Binance Risk'
                          }
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity z-40"
          onClick={handleClose}
        />
      )}
    </>
  );
};