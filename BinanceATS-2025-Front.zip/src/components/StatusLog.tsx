import React from 'react';

interface StatusLogProps {
  messages: string;
}

export const StatusLog: React.FC<StatusLogProps> = ({ messages }) => {
  return (
    <div style={{
      position: 'fixed',
      bottom: '20px',
      right: '20px',
      width: '300px',
      maxHeight: '200px',
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
      color: 'white',
      padding: '10px',
      borderRadius: '5px',
      fontSize: '12px',
      overflowY: 'auto',
      zIndex: 1000,
      fontFamily: 'monospace',
      whiteSpace: 'pre-wrap',
      wordBreak: 'break-word'
    }}>
      {messages || 'No status updates yet...'}
    </div>
  );
}; 