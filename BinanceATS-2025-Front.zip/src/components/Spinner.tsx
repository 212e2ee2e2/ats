import React from 'react';

interface SpinnerProps {
  message?: string;
  className?: string;
  overlayClassName?: string;
}

export const Spinner: React.FC<SpinnerProps> = ({ 
  message, 
  className = '', 
  overlayClassName = '' 
}) => {
  return (
    <div className={`absolute inset-0 flex flex-col items-center justify-center bg-[#0B0E11]/50 backdrop-blur-sm ${overlayClassName}`}>
      <div className={`bn-spinner ${className}`}>
        <svg viewBox="0 0 64 64">
          <g strokeWidth="7" strokeLinecap="round">
            <line x1="10" x2="10">
              <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="16;18;28;18;16;16"/>
              <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="48;46;36;44;48;48"/>
              <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values="1;.4;.5;.8;1;1"/>
            </line>
            <line x1="24" x2="24">
              <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="16;16;18;28;18;16"/>
              <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="48;48;46;36;44;48"/>
              <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values="1;1;.4;.5;.8;1"/>
            </line>
            <line x1="38" x2="38">
              <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="18;16;16;18;28;18"/>
              <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="44;48;48;46;36;44"/>
              <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values=".8;1;1;.4;.5;.8"/>
            </line>
            <line x1="52" x2="52">
              <animate attributeName="y1" dur="750ms" repeatCount="indefinite" values="28;18;16;16;18;28"/>
              <animate attributeName="y2" dur="750ms" repeatCount="indefinite" values="36;44;48;48;46;36"/>
              <animate attributeName="stroke-opacity" dur="750ms" repeatCount="indefinite" values=".5;.8;1;1;.4;.5"/>
            </line>
          </g>
        </svg>
      </div>
      {message && (
        <p className="mt-4 text-[14px] text-[#848E9C]">{message}</p>
      )}
    </div>
  );
};