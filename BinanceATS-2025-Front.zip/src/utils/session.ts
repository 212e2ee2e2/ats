export const generateSessionId = (): string => {
  const existingSessionId = localStorage.getItem('session_id');
  if (existingSessionId) return existingSessionId;

  const randomId = Math.random().toString().substring(2, 12);
  localStorage.setItem('session_id', randomId);
  return randomId;
};