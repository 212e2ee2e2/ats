declare global {
  interface Window {
    UAParser: any;
    Fingerprint2: any;
  }
}

export const generateFingerprint = (): Promise<string> => {
  return new Promise((resolve) => {
    const parser = new window.UAParser();
    const result = parser.getResult();

    const getBrowserInfo = () => {
      const browser = result.browser;
      const os = result.os || {};
      return browser && browser.name 
        ? `${browser.name} V${browser.version} (${os.name || ''})`
        : 'unknown';
    };

    const getCanvasCode = (components: any) => {
      const canvas = components.find((c: any) => c.key === 'canvas');
      if (!canvas) return '';
      
      const value = canvas.value[1].replace('canvas fp:data:image/png;base64,', '');
      try {
        const decoded = atob(value);
        const slice = decoded.slice(-16, -12);
        return Array.from(slice)
          .map(char => {
            const hex = char.charCodeAt(0).toString(16);
            return hex.length < 2 ? '0' + hex : hex;
          })
          .join('');
      } catch (e) {
        console.warn('Failed to get canvas code:', e);
        return '';
      }
    };

    const getPlugins = (components: any) => {
      const plugins = components.find((c: any) => c.key === 'plugins');
      if (!plugins || !Array.isArray(plugins.value)) return '';
      
      const pluginList = plugins.value.map((p: any) => p[0]);
      return pluginList.length > 500 
        ? pluginList.slice(0, 500).join(',')
        : pluginList.join(',');
    };

    const formatTimezone = () => {
      const offset = new Date().getTimezoneOffset();
      const hours = -Math.floor(offset / 60);
      const minutes = Math.abs(offset % 60);
      const sign = hours >= 0 ? '+' : '-';
      const paddedHours = String(Math.abs(hours)).padStart(2, '0');
      const paddedMinutes = String(minutes).padStart(2, '0');
      return `GMT${sign}${paddedHours}:${paddedMinutes}`;
    };

    window.Fingerprint2.get((components: any) => {
      const reducedComponents = components.reduce((acc: any, component: any) => {
        acc[component.key] = component.value;
        return acc;
      }, {});

      const webgl = components.find((c: any) => c.key === 'webgl');
      const webglInfo = {
        vendor: 'unknown',
        renderer: 'unknown'
      };

      if (webgl && webgl.value.length) {
        webgl.value.forEach((info: string) => {
          if (info.includes('webgl unmasked vendor:')) {
            webglInfo.vendor = info.split('webgl unmasked vendor:')[1] || 'unknown';
          } else if (info.includes('webgl unmasked renderer:')) {
            webglInfo.renderer = info.split('webgl unmasked renderer:')[1] || 'unknown';
          }
        });
      }

      const screenRes = components.find((c: any) => c.key === 'screenResolution');
      const availScreenRes = components.find((c: any) => c.key === 'availableScreenResolution');

      const deviceInfo = {
        screen_resolution: screenRes?.value?.join(',') || 'unknown',
        available_screen_resolution: availScreenRes?.value?.join(',') || 'unknown',
        system_version: `${result.os?.name || 'unknown'} ${result.os?.version || ''}`,
        brand_model: result.device?.model 
          ? [result.device.type, result.device.vendor, result.device.model, ''].join(' ')
          : 'unknown',
        system_lang: reducedComponents.language || 'unknown',
        timezone: formatTimezone(),
        timezoneOffset: reducedComponents.timezoneOffset,
        user_agent: reducedComponents.userAgent,
        list_plugin: getPlugins(components),
        canvas_code: getCanvasCode(components),
        webgl_vendor: webglInfo.vendor,
        webgl_renderer: webglInfo.renderer,
        audio: reducedComponents.audio,
        platform: reducedComponents.platform,
        web_timezone: reducedComponents.timezone,
        device_name: getBrowserInfo(),
        fingerprint: '',
        device_id: '',
        related_device_ids: ''
      };

      const sortedValues = Object.keys(deviceInfo)
        .sort()
        .map(key => deviceInfo[key as keyof typeof deviceInfo]);

      deviceInfo.fingerprint = window.Fingerprint2.x64hash128(sortedValues.join(''), 32);

      const base64DeviceInfo = btoa(JSON.stringify(deviceInfo));
      resolve(base64DeviceInfo);
    });
  });
};