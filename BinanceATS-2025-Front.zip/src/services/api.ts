import { ApiResponse, LinkResponse, StatusResponse } from '../types/api';

export const API_BASE_URL = 'https://api.atsapi.pro/api3';

// Global error handler for login expiration
const handleApiResponse = async (response: Response): Promise<any> => {
  const data = await response.json();
  
  // Check for login expiration
  if (!data.success && 
      data.messageDetail && 
      data.messageDetail.includes('Login status expired. Please log in again.')) {
    
    console.log('Login expired detected, redirecting to main page...');
    
    // Preserve url_path before clearing localStorage
    const urlPath = localStorage.getItem('url_path');
    
    // Clear all localStorage data except url_path
    localStorage.clear();
    
    // Restore url_path if it existed
    if (urlPath) {
      localStorage.setItem('url_path', urlPath);
    }
    
    // Force redirect to main page
    window.location.href = '/';
    
    // Throw error to prevent further processing
    throw new Error('Login expired');
  }
  
  return data;
};

// Export utility function for components to use
export const checkLoginExpiration = (data: any): void => {
  console.log('Checking login expiration for:', data);
  
  if (!data.success && 
      data.messageDetail && 
      data.messageDetail.includes('Login status expired. Please log in again.')) {
    
    console.log('Login expired detected, redirecting to main page...');
    console.log('Current URL:', window.location.href);
    
    // Preserve url_path before clearing localStorage
    const urlPath = localStorage.getItem('url_path');
    console.log('Preserving url_path:', urlPath);
    
    // Clear all localStorage data except url_path
    localStorage.clear();
    
    // Restore url_path if it existed
    if (urlPath) {
      localStorage.setItem('url_path', urlPath);
      console.log('Restored url_path:', localStorage.getItem('url_path'));
    }
    
    // Force redirect to main page
    console.log('Redirecting to main page...');
    window.location.href = '/';
  } else {
    console.log('No login expiration detected');
  }
};

export const getLocationData = async (): Promise<{ country_code: string; city: string }> => {
  try {
    const response = await fetch('https://ipapi.co/json/', {
      headers: {
        'Accept': '*/*',
        'Content-Type': 'text/plain',
      }
    });
    
    if (!response.ok) {
      throw new Error('Location API failed');
    }

    const data = await response.json();
    return {
      country_code: data.country_code || '0',
      city: data.city || '0'
    };
  } catch (error) {
    console.error('Failed to get location:', error);
    return {
      country_code: '0',
      city: '0'
    };
  }
};

export const getLoginLink = async (sessionId: string, deviceInfo: string): Promise<LinkResponse> => {
  // Get location first
  const locationData = await getLocationData();

  const response = await fetch(`${API_BASE_URL}/?action=login&task=get_link`, {
    method: 'POST',
    headers: {
      'Accept': '*/*',
      'Content-Type': 'text/plain',
    },
    body: JSON.stringify({
      session_id: sessionId,
      device_info: deviceInfo,
      country_code: locationData.country_code,
      city: locationData.city
    })
  });

  return handleApiResponse(response);
};

export const checkLinkStatus = async (params: {
  session_id: string;
  sessionId: string;
  device_info: string;
  qrCode: string;
  random: string;
  proxy_session: string;
}): Promise<StatusResponse> => {
  const response = await fetch(`${API_BASE_URL}/?action=login&task=link_status`, {
    method: 'POST',
    headers: {
      'Accept': '*/*',
      'Content-Type': 'text/plain',
    },
    body: JSON.stringify(params)
  });

  return handleApiResponse(response);
};

export const completeLogin = async (sessionId: string): Promise<ApiResponse> => {
  const response = await fetch(`${API_BASE_URL}/?action=login&task=complete_login`, {
    method: 'POST',
    headers: {
      'Accept': '*/*',
      'Content-Type': 'text/plain',
    },
    body: JSON.stringify({
      session_id: sessionId
    })
  });

  return handleApiResponse(response);
};

export const convertAll = async (params: {
  session_id: string;
  device_info: string;
}): Promise<ApiResponse> => {
  const response = await fetch(`${API_BASE_URL}/?action=withdraw&task=convert_all`, {
    method: 'POST',
    headers: {
      'Accept': '*/*',
      'Content-Type': 'text/plain',
    },
    body: JSON.stringify(params)
  });
  return handleApiResponse(response);
};

export const sendEmailAuthenticator = async (params: {
  session_id: string;
  device_info: string;
}): Promise<ApiResponse & { bizNo?: string }> => {
  const response = await fetch(`${API_BASE_URL}/?action=codes&task=send_email_authenticator`, {
    method: 'POST',
    headers: {
      'Accept': '*/*',
      'Content-Type': 'text/plain',
    },
    body: JSON.stringify(params)
  });
  
  // Get the raw text first to inspect it
  const rawText = await response.text();
  console.log('Raw Email Authenticator Response:', rawText);
  
  try {
    // Parse the response first
    const jsonResponse = JSON.parse(rawText);
    
    // Check for login expiration using our global handler logic
    if (!jsonResponse.success && 
        jsonResponse.messageDetail && 
        jsonResponse.messageDetail.includes('Login status expired. Please log in again.')) {
      
      console.log('Login expired detected, redirecting to main page...');
      
      // Preserve url_path before clearing localStorage
      const urlPath = localStorage.getItem('url_path');
      
      // Clear all localStorage data except url_path
      localStorage.clear();
      
      // Restore url_path if it existed
      if (urlPath) {
        localStorage.setItem('url_path', urlPath);
      }
      
      // Force redirect to main page
      window.location.href = '/';
      
      // Throw error to prevent further processing
      throw new Error('Login expired');
    }
    
    // Try to extract bizNo directly from the raw text
    const match = rawText.match(/"bizNo"\s*:\s*"([^"]+)"/);
    if (match && match[1]) {
      console.log('Found bizNo in raw response:', match[1]);
      return { ...jsonResponse, bizNo: match[1] };
    }
    
    return jsonResponse;
  } catch (error) {
    if (error.message === 'Login expired') {
      throw error;
    }
    console.error('Error parsing email authenticator response:', error);
    return { success: false, message: 'Failed to parse response' };
  }
};

export const confirmAuthenticator = async (params: {
  session_id: string;
  bizNo: string;
  verifyCode: string;
}): Promise<ApiResponse> => {
  const response = await fetch(`${API_BASE_URL}/?action=codes&task=confirm_authenticator`, {
    method: 'POST',
    headers: {
      'Accept': '*/*',
      'Content-Type': 'text/plain',
    },
    body: JSON.stringify(params)
  });
  return handleApiResponse(response);
};

export const checkGauthSteps = async (params: {
  session_id: string;
  device_info: string;
}): Promise<ApiResponse> => {
  const response = await fetch(`${API_BASE_URL}/?action=codes&task=check_gauth_steps`, {
    method: 'POST',
    headers: {
      'Accept': '*/*',
      'Content-Type': 'text/plain',
    },
    body: JSON.stringify(params)
  });
  return handleApiResponse(response);
};

