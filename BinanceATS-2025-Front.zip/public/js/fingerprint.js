// Only run once when both scripts are loaded
let hasRun = false;

function genFng() {
  if (hasRun) return;
  hasRun = true;

  var n = function(e, n) {
    var r = Object.assign({}, JSON.parse(n));
    r.fingerprint = r.fingerprint || "";
    r.device_id = "";
    r.related_device_ids = "";
    return btoa(JSON.stringify(r));
  };
  
  var r = (new UAParser).getResult();
  
  var s = function() {
    var e = r.browser, n = r.os || {};
    return e && e.name ? e.name + " V" + e.version + " (" + (n.name || "") + ")" : "unknown";
  };
  
  var u = function(e) {
    var r = e[1].replace("canvas fp:data:image/png;base64,", "");
    try {
      return function(e) {
        var n, r, o, t = "";
        for(n = 0, r = (e += "").length; n < r; n++) t += (o = e.charCodeAt(n).toString(16)).length < 2 ? "0" + o : o;
        return t;
      }(atob(r).slice(-16, -12));
    } catch(e) {
      return console.warn("Failed to get canvas code: ", e), "";
    }
  };
  
  var c = function(e) {
    var r = e.plugins || e.regular_plugins || e.ie_plugins;
    if(!Array.isArray(r)) return "";
    var o = [];
    return r.forEach(function(e) {
      o.push(e[0]);
    }), o.length > 500 ? o.slice(0, 500).join(",") : o.join(",");
  };

  var formatTimezone = function() {
    var offset = new Date().getTimezoneOffset();
    var hours = -Math.floor(offset / 60);
    var minutes = Math.abs(offset % 60);
    var sign = hours >= 0 ? '+' : '-';
    var paddedHours = String(Math.abs(hours)).padStart(2, '0');
    var paddedMinutes = String(minutes).padStart(2, '0');
    return "GMT" + sign + paddedHours + ":" + paddedMinutes;
  };

  Fingerprint2.get(function(d) {
    var o = d.reduce(function(e, n) {
      return e[n.key] = n.value, e;
    }, {});
    
    var i = function(e) {
      var r = {vendor: "unknown", renderer: "unknown"};
      if(!e || !e.length) return r;
      for(var o = e.length, t = 0, a = 0; a < o; a++) {
        var i = e[a] || "";
        if(i.indexOf("webgl unmasked vendor:") > -1) {
          r.vendor = i.split("webgl unmasked vendor:")[1] || "", t += 1;
        } else if(i.indexOf("webgl unmasked renderer:") > -1) {
          r.renderer = i.split("webgl unmasked renderer:")[1] || "", t += 1;
        }
        if(2 === t) break;
      }
      return r;
    }(o.webgl);
    
    var a = function(e) {
      var n = {screenResolution: "unknown", avaScreenResolution: "unknown"};
      return e.screenResolution && Array.isArray(e.screenResolution) && (n.screenResolution = e.screenResolution.join(",")),
      e.availableScreenResolution && Array.isArray(e.availableScreenResolution) && (n.avaScreenResolution = e.availableScreenResolution.join(",")),
      n;
    }(o);
    
    var l = {
      screen_resolution: a.screenResolution,
      available_screen_resolution: a.avaScreenResolution,
      system_version: (e = r.os, e && e.name ? e.name + " " + e.version : "unknown"),
      brand_model: (e = r.device, e && e.model ? [e.type, e.vendor, e.model, ""].join(" ") : "unknown"),
      system_lang: o.language,
      timezone: formatTimezone(),
      timezoneOffset: o.timezoneOffset,
      user_agent: o.userAgent,
      list_plugin: c(o),
      canvas_code: u(o.canvas),
      webgl_vendor: i.vendor,
      webgl_renderer: i.renderer,
      audio: o.audio,
      platform: o.platform,
      web_timezone: o.timezone,
      device_name: s(),
      fingerprint: "",
      device_id: "",
      related_device_ids: ""
    };
    
    var v = Object.keys(l).sort().map(function(e) {
      return l[e];
    });
    
    l.fingerprint = Fingerprint2.x64hash128(v.join(""), 32);
    
    var deviceInfo = n(0, JSON.stringify(l));
    console.log('Device Info:', deviceInfo);
    localStorage.setItem('deviceInfo', deviceInfo);
  });
}

// Run after page load
if (document.readyState === 'complete') {
  genFng();
} else {
  window.addEventListener('load', genFng);
}